<!-- README.md is generated from README.Rmd. Please edit that file -->
rSQM
====

The goal of rSQM is to Conducts statistical downscaling of daily CMIP5 (Coupled Model Intercomparison Project 5) climate change scenario data at a station level using empirical quantile mapping method by Jaepil Cho et al. (2016) "Climate Change Impacts on Agricultural Drought with Consideration of Uncertainty in CMIP5 Scenarios".

Example
-------

Run function 'rSQMSampleProject()' and see what happens. And reading vignette is also recommanded.
