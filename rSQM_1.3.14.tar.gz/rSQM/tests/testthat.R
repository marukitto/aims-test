library(testthat)
library(rSQM)

test_check("rSQM")
