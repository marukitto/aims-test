# rSQM 1.3.13

fixed some minor bugs, enriched vignette
