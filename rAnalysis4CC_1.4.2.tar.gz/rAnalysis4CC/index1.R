# simple sum of all prec
index1 <- function(index, tmax, tmin, tavg, prec) {
  ans <- tapply(prec, index, sum)
  ans <- unlist(ans, recursive = FALSE)
  names(ans) <- levels(index)
  return(ans)
}
