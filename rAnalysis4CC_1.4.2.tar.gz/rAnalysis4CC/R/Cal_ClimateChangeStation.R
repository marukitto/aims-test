ClimateChangeStation <- function(CCSmrDir,dsnm,rcpnms,syear_scn,eyear_scn){
  obsdir <- paste(CCSmrDir,"/Raw/",dsnm,sep="")
  rcpnms <- unique(c("Historical",rcpnms))
  flist <- list.rbind(strsplit(list.files(obsdir),"_"))
  stnnms <- unique(flist[,2])
  varnms <- unique(flist[,1])
  seasonstart <- c(3,6,9,12)
  Seasons <- c("Spring","Summer","Autumn","Winter")
  syear_scns <- syear_scn
  eyear_scns <- eyear_scn
  futscns <- c("Repro","Future01","Future02","Future03")
  futscns <- futscns[1:(1+length(syear_scn))]
  RCPNMS <- unique(c("Historical",rcpnms))
  gdir <- paste(CCSmrDir,"/Graph",sep="")
  if(!dir.exists(gdir)){dir.create(gdir)}
  graphdir <- paste(CCSmrDir,"/Graph/",dsnm,"/",sep="")
  if(!dir.exists(graphdir)){dir.create(graphdir)}
  fulvarnms <- c("Minimum Temperature","Maximum Temperature","Precipitation")
  test <- read.csv(paste(obsdir,"/",list.files(obsdir)[1],sep=""))
  gcmnms <- colnames(test)[2:(ncol(test)-6)]

  cliamtechangedata <- Make.GcmChange.Data(obsdir,stnnms,varnms,RCPNMS,fulvarnms)
  Make.GcmChange.graph(graphdir,stnnms,varnms,RCPNMS,fulvarnms,graphdata)

  season_boxplot_data <-
    Make.SeasonChange.Data(obsdir,gcmnms,stnnms,varnms,rcpnms,futscns,fulvarnms,syear_scns,eyear_scns,seamon)
  Make.Season.Boxplot(graphdir,stnnms,varnms,rcpnms,futscns,fulvarnms,season_boxplot_data)

  monthlychangedata <- Make.MonthlyChange.Data(obsdir,gcmnms,stnnms,varnms,RCPNMS,futscns,fulvarnms,syear_scns,eyear_scns,seamon)
  Make.MonthlyCahnge.Graph(graphdir,stnnms,varnms,RCPNMS,futscns,fulvarnms,monthlychangedata)
}
