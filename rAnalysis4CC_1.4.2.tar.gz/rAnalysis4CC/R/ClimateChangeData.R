ClimateChangeData <- function(sel_gcmnms,VarNames,stndir,stnfile,CCSmrDir,syear_his,eyear_his,
                              syear_scn,eyear_scn,syear_obs,eyear_obs,rcpnms,DsDir,sel_dsnms,...){
  sel_gcmnms <- EnvList$sel_gcmnms
  VarNames <- EnvList$VarNames
  stndir <- EnvList$stndir
  stnfile <- EnvList$stnfile
  CCSmrDir <- EnvList$CCSmrDir
  syear_his <- EnvList$syear_his
  eyear_his <- EnvList$eyear_his
  syear_scn <- EnvList$syear_scn
  eyear_scn <- EnvList$eyear_scn
  syear_obs <- EnvList$syear_obs
  eyear_obs <- EnvList$eyear_obs
  rcpnms <- EnvList$rcpnms
  DsDir <- EnvList$DsDir
  sel_dsnms <- EnvList$sel_dsnms
  smon <- 1
  emon <- 12

  Cal.ClimateChangeData(sel_gcmnms,VarNames,stndir,stnfile,CCSmrDir,syear_his,eyear_his,
                                    syear_scn,eyear_scn,syear_obs,eyear_obs,rcpnms,DsDir,sel_dsnms,smon,emon)
  # ClimateChangeStation(CCSmrDir,dsnm,rcpnms,syear_scn,eyear_scn)
  ClimateChangeKorea(CCSmrDir,dsnm,rcpnms,syear_scn,eyear_scn)
}
