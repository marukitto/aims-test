ClimateChangeKorea <- function(CCSmrDir,dsnm,rcpnms,syear_scn,eyear_scn){
  #CCSmrDir <- EnvList$CCSmrDir
  obsdir <- paste(CCSmrDir,"/Raw/",dsnm,sep="")
  outdir <- paste(CCSmrDir,"/Raw/",dsnm,"_Korea",sep="")
  if(!dir.exists(outdir)){dir.create(outdir)}
  flist <- list.rbind(strsplit(list.files(obsdir),"_"))
  stnnms <- unique(flist[,2])
  varnms <- unique(flist[,1])
  seasonstart <- c(3,6,9,12)
  Seasons <- c("Spring","Summer","Autumn","Winter")
  syear_scns <- syear_scn
  eyear_scns <- eyear_scn
  futscns <- c("Repro","Future01","Future02","Future03")
  futscns <- futscns[1:(1+length(syear_scn))]
  temppat <- paste(varnms[1],"_",stnnms[1],"_*.csv",sep="")
  templist <- list.files(obsdir,pattern = glob2rx(temppat))
  Tempflist <- strsplit(templist,"_")

  for(i_var in 1:length(varnms)){
    varnm <- varnms[i_var]
    for(i_flist in 1:length(Tempflist)){
      filenm <- Tempflist[[i_flist]]
      tempf <- filenm[-(1:2)]
      for(i_te in 1:length(tempf)){
        if(i_te == 1){
          Tempf <- tempf[i_te]
        } else {
          Tempf <- paste(Tempf,tempf[i_te],sep="_")
        }
      }
      for(i_stn in 1:length(stnnms)){
        stnnm <- stnnms[i_stn]
        filenm <- paste(obsdir,"/",varnm,"_",stnnm,"_",Tempf,sep="")
        Tempdat <- read.csv(filenm)
        colname <- colnames(Tempdat)
        Firstcol <- Tempdat[,1]
        Tempdat <- Tempdat[,-1]
        if(i_stn == 1){
          TEMP <- Tempdat
        } else {
          TEMP <- TEMP + Tempdat
        }
      }
      TEMP1 <- TEMP / length(stnnms)
      TEMP1 <- data.frame(Firstcol,TEMP1)
      colnames(TEMP1) <- colname
      outnm <- paste(outdir,"/",varnm,"_Korea_",Tempf,sep="")
      write.csv(TEMP1,outnm,row.names = F)
    }
  }

  gdir <- paste(CCSmrDir,"/Graph",sep="")
  if(!dir.exists(gdir)){dir.create(gdir)}
  graphdir <- paste(CCSmrDir,"/Graph/",dsnm,"_Korea/",sep="")
  if(!dir.exists(graphdir)){dir.create(graphdir)}
  Koreadir <- paste(CCSmrDir,"/Raw/",dsnm,"_Korea",sep="")
  fulvarnms <- c("Minimum Temperature","Maximum Temperature","Precipitation")
  stnnms <- "Korea"
  syear_scn <- syear_scns[1]
  eyear_scn <- eyear_scns[1]
  test <- read.csv(paste(Koreadir,"/",list.files(Koreadir)[1],sep=""))
  gcmnms <- colnames(test)[2:(ncol(test)-6)]
  #########Season boxplot
  seamon <- list()
  for(i_sea in 1:length(seasonstart)){
    temp <- c(seasonstart[i_sea],seasonstart[i_sea]+1,seasonstart[i_sea]+2)
    if(sum(temp > 12)>0){
      wh <- which(temp > 12)
      temp[wh] <- temp[wh] - 12
      seamon[[i_sea]] <- temp
    } else {
      seamon[[i_sea]] <- temp
    }
  }
  RCPNMS <- unique(c("Historical",rcpnms))
  cliamtechangedata <- Make.GcmChange.Data(outdir,stnnms,varnms,RCPNMS,fulvarnms)
  Make.GcmChange.graph(graphdir,stnnms,varnms,RCPNMS,fulvarnms,cliamtechangedata)

  season_boxplot_data <-
    Make.SeasonChange.Data(outdir,gcmnms,stnnms,varnms,rcpnms,futscns,fulvarnms,syear_scns,eyear_scns,seamon)
  Make.Season.Boxplot(graphdir,stnnms,varnms,rcpnms,futscns,fulvarnms,season_boxplot_data)

  monthlychangedata <- Make.MonthlyChange.Data(outdir,gcmnms,stnnms,varnms,RCPNMS,futscns,fulvarnms,syear_scns,eyear_scns,seamon)
  Make.MonthlyCahnge.Graph(graphdir,stnnms,varnms,RCPNMS,futscns,fulvarnms,monthlychangedata)
}
