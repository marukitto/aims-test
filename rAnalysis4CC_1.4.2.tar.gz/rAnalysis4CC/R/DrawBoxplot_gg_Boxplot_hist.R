#' @export
gg.boxplot.hist <- function(X,Y,fname,Rep,idxnm,dsnms,gcmnms){
  # X <- DataBox[[i_CLIM]]
  # Y <- TEMPDATA
  # idxnm <- idxnms[i_CLIM]

  set.seed(2018)
  titleidx <- find.fullidxnm(idxnm)
  OBSlen <- length(which(X[,"dsnms"]=="OBS"))
  nms <- as.character(unique(X[,"dsnms"]))
  tblmat <- matrix(NA,7,length(nms))
  for(i_smy in 1:length(nms)){
    wh <- which(X[,"dsnms"] == nms[i_smy])
    temp <- X[wh,"value"]
    for(j_smy in 1:6){
      tblmat[j_smy,i_smy] <- round(summary(temp)[j_smy],2)
    }
    if(i_smy == 1){
      NAs <- Rep - length(wh)
    } else {
      NAs <- Rep * (length(unique(X[,"gcmnms"])) - 1) - length(wh)
    }
    tblmat[7,i_smy] <- round(NAs,0)
  }
  rownames(tblmat) <- c(names(summary(temp)),"NA Count(Year)")
  colnames(tblmat) <- nms

  ##make data for line plot
  YEAR <- seq(1,Rep)
  TEMPOBS <- Y[which(Y[,"dsnms"]=="OBS"),"value"]
  for(i_lnp in 1:length(dsnms)){
    TEMP <- Y[which(Y[,"dsnms"]==dsnms[i_lnp]),]
    for(j_lnp in 1:length(gcmnms)){
      if(j_lnp==1){
        TEMPMAT <- TEMP[which(TEMP[,"gcmnms"]==gcmnms[j_lnp]),"value"]
      } else {
        TEMPMAT <- data.frame(TEMPMAT,TEMP[which(TEMP[,"gcmnms"]==gcmnms[j_lnp]),"value"])
      }
      tempd <- data.frame(YEAR,TEMP[which(TEMP[,"gcmnms"]==gcmnms[j_lnp]),"value"],dsnms[i_lnp])
      colnames(tempd) <- c("YEAR","value","Method")
      tempd <- data.frame(tempd)
      if(i_lnp==1 & j_lnp == 1){
        FULLDATA <- tempd
      } else {
        FULLDATA <- rbind(FULLDATA,tempd)
      }
    }
    if(length(gcmnms)==1){
      TEMPMat <- TEMPMAT
    } else {
      TEMPMat <- apply(TEMPMAT,1,mean,na.rm=T)
    }
    if(i_lnp == 1){
      TMPmat <- TEMPMat
    } else {
      TMPmat <- data.frame(TMPmat,TEMPMat)
    }
  }

  TMPmat1 <- data.frame(YEAR,TEMPOBS,TMPmat)
  colnames(TMPmat1) <- c("YEAR",unique(nms))
  TEMPmat <- melt(TMPmat1,id="YEAR")
  TEMPmat$Count <- -99; FULLDATA$Count <- -99

  for(i_rnk in 1:length(nms)){
    nm <- as.character(nms[i_rnk])
    wh <- which(TEMPmat[,"variable"]==nm)
    tmp <- TEMPmat[wh,]
    rnktmp <- rank(-tmp[,3],ties.method = "random")

    if(i_rnk != 1){
      WH <- which(as.character(FULLDATA[,"Method"])==nm)
      #print(WH)
    }
    for(j_rnk in 1:length(YEAR)){
      jj <- j_rnk + (i_rnk-1)*length(YEAR)
      TEMPmat[jj,"Count"] <- rnktmp[j_rnk]
      if(i_rnk != 1){
      WH1 <- which(FULLDATA[WH,"YEAR"]==j_rnk)
      FULLDATA[WH[WH1],"Count"] <- rnktmp[j_rnk]
      }
    }
  }

  for(i_na in 1:length(nms)){
    nm <- nms[i_rnk]
    wh <- which(as.character(TEMPmat[,"variable"])==nm)
    tblmat[7,i_na] <- sum(is.na(TEMPmat[wh,"value"]))
  }
  #print(FULLDATA)
  if("BCSA" %in% dsnms){
    graphcolors <- c("seagreen","slategrey","slateblue3","palevioletred")
  } else {
    graphcolors <- c("slategrey","palevioletred","seagreen","slateblue3")
  }

  ggline <- ggplot(data=FULLDATA,aes(x=Count,y=value)) +
    geom_point(aes(color=Method),alpha=1/5,pch=16) +
    geom_line(data=TEMPmat,aes(x=Count,y=value,colour=variable)) +
    theme(plot.title=element_text(size=18,hjust=0.5),panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),axis.title = element_text(size=13),
          axis.text = element_text(size=12),legend.text = element_text(size=11),
          legend.title = element_text(size=11)) +
    #labs(title = paste("Plot of ",titleidx[1]," (",titleidx[3],")",sep=""), x="Count (Year)") +
    scale_fill_manual(values=wes_palette(n=3, name="GrandBudapest")) + ylab(idxnm)
  ggline <- ggline + scale_colour_manual(values = graphcolors[1:(length(dsnms)+1)])
  ###Draw ggplot
  minx <- trunc(min(X[,"value"])) - 1
  maxx <- round(max(X[,"value"]),0)
  byx <- round((maxx - minx)/6,0)
  maxx <- maxx + byx
  X$Method <- X$dsnms
  #write.csv(X,fname1)
  #print(length(dsnms))
  if(length(dsnms)==1){
    p = ggplot(data=X, aes(x=factor(dsnms, levels=unique(dsnms)),y=value,fill=Method)) +
      facet_grid(. ~ Cate_f, scales = "free", space="free_x") +
      geom_boxplot(width = 0.5) +
      #scale_x_discrete(name = "Downscaling Method") +
      scale_x_discrete(name = NULL) +
      geom_hline(yintercept = median(X[1:OBSlen,1]),color = "red") +
      theme_bw() + theme(plot.title=element_text(size=20,hjust=0.5),panel.grid.major = element_blank(),
                         panel.grid.minor = element_blank(),legend.text = element_text(size=13),
                         legend.title = element_text(size=13),axis.title = element_text(size=13),
                         axis.text = element_text(size=12))+
      #ggtitle(paste("Boxplot of ",idxnm,sep=""))
      labs(title = paste("Boxplot of ",titleidx[1],":",titleidx[2]," (",titleidx[3],")",sep="")) + ylab(idxnm)
  } else {
    p = ggplot(data=X, aes(x=factor(dsnms, levels=unique(dsnms)),y=value,fill=Method)) +
      facet_grid(. ~ Cate_f, scales = "free", space="free_x") +
      geom_boxplot() +
      #scale_x_discrete(name = "Downscaling Method") +
      scale_x_discrete(name = NULL) +
      geom_hline(yintercept = median(X[1:OBSlen,1]),color = "red") +
      theme_bw() + theme(plot.title=element_text(size=20,hjust=0.5),panel.grid.major = element_blank(),
                         panel.grid.minor = element_blank(),legend.text = element_text(size=13),
                         legend.title = element_text(size=13),axis.title = element_text(size=13),
                         axis.text = element_text(size=12))+
      #ggtitle(paste("Boxplot of ",idxnm,sep=""))
      labs(title = paste("Boxplot of ",titleidx[1],":",titleidx[2]," (",titleidx[3],")",sep="")) + ylab(idxnm)
  }


  if(byx > 0){
    p = p + scale_y_continuous(name = idxnm, breaks = seq(minx,maxx,byx), limits=c(minx,maxx))
  } else {
    p = p + scale_y_continuous(name = idxnm, limits=c(minx,maxx))
  }
  p <- p  + scale_fill_manual(values = graphcolors[1:(length(dsnms)+1)])

  #ggsave(fname2,plot=p)
  #tt <- ttheme_default(base_size = 5)
  #tbl <- tableGrob(tblmat, theme=tt)
  stable <- ggtexttable(tblmat,theme=ttheme(base_size = 10,colnames.style = colnames_style(fill="white")))
  # A helper function to define a region on the layout
  # png(fname,width=750,height=750)
  # print(p)
  # dev.off()
  #
  png(fname,width=750,height=750)
  grid.newpage()
  # Create layout
  pushViewport(viewport(layout = grid.layout(nrow = 40, ncol = 25)))
  #print("start viewpoint")
  # Arrange the plots
  print(p, vp = define_region(row = 2:23, col = 2:24))   # Span over two columns
  #print("first")
  print(ggline, vp = define_region(row = 25:39, col = 2:14))
  #print("2nd")
  print(stable, vp = define_region(row = 29:33, col = 16:23))
  #print("last")
  dev.off()

  #ggsave(fname, plot=pp)#, width = 16, height = 12, units = 'in', dpi = 600)
}

