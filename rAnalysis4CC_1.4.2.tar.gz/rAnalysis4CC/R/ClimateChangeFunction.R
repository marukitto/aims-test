calculate.season.sum <- function(mondat,seamon){
  for(i_sea in 1:length(seamon)){
    temp <- round(apply(subset(mondat[,-1],mondat$month == seamon[[i_sea]][1] |
                                 mondat$month == seamon[[i_sea]][2] | mondat$month == seamon[[i_sea]][3]),2,sum),2)
    tempnms <- names(temp)
    if(i_sea == 1){
      out <- temp
    } else {
      out <- rbind(out,temp)
    }
  }
  rownames(out) <- NULL
  return(out)
}

calculate.season.mean <- function(mondat,seamon){
  for(i_sea in 1:length(seamon)){
    temp <- round(apply(subset(mondat[,-1],mondat$month == seamon[[i_sea]][1] |
                                 mondat$month == seamon[[i_sea]][2] | mondat$month == seamon[[i_sea]][3]),2,mean),2)
    tempnms <- names(temp)
    if(i_sea == 1){
      out <- temp
    } else {
      out <- rbind(out,temp)
    }
  }
  rownames(out) <- NULL
  return(out)
}

Make.SeasonChange.Data <- function(dir,gcmnms,stnnms,varnms,rcpnms,futscns,fulvarnms,syear_scns,eyear_scns,seamon){
  outs <- out <- out1 <- list()
  futnms <- futscns[-1]
  for(i_var in 1:length(varnms)){
    varnm <- varnms[i_var]
    for(i_stn in 1:length(stnnms)){
      stnnm <- stnnms[i_stn]
      for(i_fut in 1:length(futnms)){
        futnm <- futnms[i_fut]
        syear_scn <- syear_scns[i_fut]
        eyear_scn <- eyear_scns[i_fut]
        for(i_rcp in 1:length(rcpnms)){
          rcpnm <- rcpnms[i_rcp]
          if(rcpnms[i_rcp] == "historical"){
            futnm1 <- "Repro"
            tempfile <- paste(varnm,"_",stnnm,"_",futnm1,"_*.csv",sep="")
          } else {
            tempfile <- paste(varnm,"_",stnnm,"_",futnm,"_",rcpnm,"_SY",syear_scn,"EY",eyear_scn,"_*.csv",sep="")
          }
          filenm <- list.files(dir,pattern = glob2rx(tempfile))
          datdir <- paste(dir,"/",filenm,sep="")
          data <- read.csv(datdir)[,c("month",gcmnms)]
          mondat <- data[-which(data[,"month"]=="Sum/Avg"),]
          if(varnm == "prcp"){
            avgdat <- apply(mondat[,-1],2,sum)
          } else {
            avgdat <- apply(mondat[,-1],2,mean)
          }
          if(varnm == "prcp"){
            mondat <- calculate.season.sum(mondat,seamon)
          } else {
            mondat <- calculate.season.mean(mondat,seamon)
          }
          mondat <- data.frame(Seasons,mondat)
          meltmondat <- melt(mondat,id="Seasons")
          tempdat <- data.frame(meltmondat,rcpnm,"Seasons")
          meltavgdat <- melt(avgdat)
          tempavg <- data.frame("Sum/Avg",rownames(meltavgdat),meltavgdat,rcpnm,"Avg")
          rownames(tempavg) <- NULL
          colnames(tempdat) <- colnames(tempavg) <- c("Month","variable","value","RcpSenarios","Categori")
          if(i_rcp == 1){
            outdat <- rbind(tempavg,tempdat)
          } else {
            outdat <- rbind(outdat,tempavg,tempdat)
          }
        }
        colnames(outdat) <- c("Month","variable","value","RcpSenarios","Categori")
        out1[[i_fut]] <- outdat
      }
      names(out1) <- futnms
      out[[i_stn]] <- out1
    }
    names(out) <- stnnms
    outs[[i_var]] <- out
  }
  names(outs) <- varnms
  return(outs)
}

Make.Season.Boxplot <- function(graphdir,stnnms,varnms,rcpnms,futscns,fulvarnms,graphdata){
  if(!dir.exists(graphdir)){dir.create(graphdir)}
  outgraphdir <- paste(graphdir,"/SeasonBoxplot",sep="")
  if(!dir.exists(outgraphdir)){dir.create(outgraphdir)}
  futnms <- futscns[-1]
  for(i_var in 1:length(varnms)){
    varnm <- varnms[i_var]
    if(varnm == "prcp"){
      fvarnm <- fulvarnms[3]
    } else if(varnm == "tmax"){
      fvarnm <- fulvarnms[2]
    } else if(varnm == "tmin"){
      fvarnm <- fulvarnms[1]
    }
    for(i_stn in 1:length(stnnms)){
      stnnm <- stnnms[i_stn]
      for(i_fut in 1:length(futnms)){
        futnm <- futnms[i_fut]
        outdat <- graphdata[[varnm]][[stnnm]][[futnm]][,"value"]
        if(i_stn == 1 & i_fut == 1){
          tempmin <- min(outdat)
          tempmax <- max(outdat)
          tempmin1 <- tempmin
          tempmax1 <- tempmax
        } else {
          tempmin <- min(outdat)
          tempmax <- max(outdat)
          tempmin1 <- c(tempmin1,tempmin)
          tempmax1 <- c(tempmax1,tempmax)
        }
      }
    }
    Ymax <- max(tempmax1)
    Ymin <- min(tempmin1)
    for(i_stn in 1:length(stnnms)){
      g <- list()
      for(i_fut in 1:length(futnms)){
        futnm <- futnms[i_fut]
        stnnm <- stnnms[i_stn]
        outdat <- graphdata[[varnm]][[stnnm]][[futnm]]
        titlenm <- paste("Boxplot of ",fvarnm," ",futnm," Boxplot",sep="")
        g[[i_fut]] <- ggplot(outdat, aes(x=factor(Month,levels = unique(Month)),y=value,fill=RcpSenarios)) +
          geom_boxplot() +
          facet_grid(. ~ Categori,scales = "free",space = "free_x") +
          labs(y=fvarnm,title=titlenm,x=NULL) +
          #scale_x_continuous(breaks = c(syear_his,hisfut,eyear_scn),labels = c(syear_his,eyear_his,eyear_scn)) +
          coord_cartesian(ylim = c(Ymin,Ymax)) +
          theme(plot.title = element_text(hjust=0.5))
      }
      pngnm <- paste(outgraphdir,"/",varnm,"_",stnnm,"_Boxplot.png",sep="")
      gg <- grid.arrange(g[[1]],g[[2]],g[[3]],ncol=2)
      ggsave(gg,filename = pngnm,width = 11,height = 7)
    }
  }
}

########Cliamte Change
Make.GcmChange.Data <- function(dir,stnnms,varnms,rcpnms,fulvarnms){
  outs <- out <- list()
  for(i_var in 1:length(varnms)){
    varnm <- varnms[i_var]
    for(i_stn in 1:length(stnnms)){
      stnnm <- stnnms[i_stn]
      for(i_rcp in 1:length(rcpnms)){
        rcpnm <- rcpnms[i_rcp]
        filenm <- paste(dir,"/",varnm,"_",stnnm,"_Annual_",rcpnm,".csv",sep="")
        data <- read.csv(filenm)
        tempdat <- data.frame(data[,c("Year","Min.","Max.","Mean")],rcpnm)
        if(i_rcp == 1){
          outdat <- tempdat
          syear_his <- min(tempdat[,"Year"])
          eyear_his <- max(tempdat[,"Year"])
        } else {
          outdat <- rbind(outdat,tempdat)
          syear_scn <- min(tempdat[,"Year"])
          eyear_scn <- max(tempdat[,"Year"])
        }
      }
      colnames(outdat) <- c("Year","Min","Max","Mean","RcpScenarios")
      out[[i_stn]] <- outdat
    }
    names(out) <- stnnms
    outs[[i_var]] <- out
  }
  names(outs) <- varnms
  return(outs)
}


Make.GcmChange.graph <- function(graphdir,stnnms,varnms,rcpnms,fulvarnms,graphdata){
  if(!dir.exists(graphdir)){dir.create(graphdir)}
  outgraphdir <- paste(graphdir,"/ClimateChange",sep="")
  if(!dir.exists(outgraphdir)){dir.create(outgraphdir)}
  for(i_var in 1:length(varnms)){
    varnm <- varnms[i_var]
    if(varnm == "prcp"){
      fvarnm <- fulvarnms[3]
    } else if(varnm == "tmax"){
      fvarnm <- fulvarnms[2]
    } else if(varnm == "tmin"){
      fvarnm <- fulvarnms[1]
    }
    for(i_stn in 1:length(stnnms)){
      stnnm <- stnnms[i_stn]
      outdat <- graphdata[[varnm]][[stnnm]]
      if(i_stn == 1){
        tempmin <- min(outdat[,"Min"])
        tempmax <- max(outdat[,"Max"])
        tempmin1 <- tempmin
        tempmax1 <- tempmax
      } else {
        tempmin <- min(outdat[,"Min"])
        tempmax <- max(outdat[,"Max"])
        tempmin1 <- c(tempmin1,tempmin)
        tempmax1 <- c(tempmax1,tempmax)
      }
    }
    Ymax <- max(tempmax1)
    Ymin <- min(tempmin1)
    for(i_stn in 1:length(stnnms)){
      stnnm <- stnnms[i_stn]
      outdat <- graphdata[[varnm]][[stnnm]]
      wh <- which(outdat[,"RcpScenarios"] == rcpnms[1])
      syear_his <- min(outdat[wh,"Year"])
      eyear_his <- max(outdat[wh,"Year"])
      syear_scn <- min(outdat[-wh,"Year"])
      eyear_scn <- max(outdat[-wh,"Year"])
      hisfut <- mean(c(eyear_his,syear_scn))
      titlenm <- paste("GCM average(range) ",fvarnm," change",sep="")
      g <- ggplot(data=outdat, aes(x=Year,y=Mean,col=RcpScenarios)) +
        geom_ribbon(aes(ymin=Min, ymax=Max,fill=RcpScenarios),alpha=0.5,colour=NA) +
        geom_line(size=1) + geom_vline(xintercept = hisfut,size=1) +
        labs(y=fvarnm,title=titlenm) +
        scale_x_continuous(breaks = c(syear_his,hisfut,eyear_scn),labels = c(syear_his,eyear_his,eyear_scn)) +
        coord_cartesian(xlim = c((syear_his+4.5),(eyear_scn-4)),ylim = c(Ymin,Ymax)) +
        theme(legend.position = "bottom",panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
              plot.title = element_text(hjust=0.5))
      pngnm <- paste(outgraphdir,"/",varnm,"_",stnnm,"_Annual.png",sep="")
      ggsave(g,filename = pngnm,width = 9,height = 6)
    }
  }
}

########Monthly Cahnge(range)
Make.MonthlyChange.Data <- function(dir,gcmnms,stnnms,varnms,rcpnms,futscns,fulvarnms,syear_scns,eyear_scns,seamon){
  outs <- out1 <- out <- list()
  for(i_var in 1:length(varnms)){
    varnm <- varnms[i_var]
    for(i_stn in 1:length(stnnms)){
      stnnm <- stnnms[i_stn]
      for(i_fut in 1:length(futscns)){
        futscn <- futscns[i_fut]
        if(i_fut == 1){
          tempfiles <- paste(varnm,"_",stnnm,"_",futscn,"_*.csv",sep="")
        } else {
          syear_scn <- syear_scns[i_fut - 1]
          eyear_scn <- eyear_scns[i_fut - 1]
          tempfiles <- paste(varnm,"_",stnnm,"_",futscn,"_*_SY",syear_scn,"EY",eyear_scn,"_*.csv",sep="")
        }
        filenms <- list.files(dir,pattern = glob2rx(tempfiles))
        for(i_rcp in 1:length(filenms)){
          filenm <- filenms[i_rcp]
          datdir <- paste(dir,"/",filenm,sep="")
          data <- read.csv(datdir)
          mondat <- data[-which(data[,"month"]=="Sum/Avg"),]
          if(i_fut == 1){
            categori1 <- "OBS"
            categori2 <- rcpnms[i_rcp]
          } else {
            categori1 <- rcpnms[1]
            categori2 <- rcpnms[i_rcp + 1]
          }
          dat1 <- data.frame(sort(unique(as.numeric(mondat[,"month"]))),mondat[,2],mondat[,2],mondat[,2],categori1)
          dat2 <- data.frame(sort(unique(as.numeric(mondat[,"month"]))),mondat[,c("Min.","Mean","Max.")],categori2)

          colnames(dat1) <- colnames(dat2) <- c("Month","Min","Mean","Max","Categori")
          if(i_rcp == 1){
            outdat <- rbind(dat1,dat2)
          } else {
            outdat <- rbind(outdat,dat2)
          }
        }
        out1[[i_fut]] <- outdat
      }
      names(out1) <- futscns
      out[[i_stn]] <- out1
    }
    names(out) <- stnnms
    outs[[i_var]] <- out
  }
  names(outs) <- varnms
  return(outs)
}

Make.MonthlyCahnge.Graph <- function(graphdir,stnnms,varnms,rcpnms,futscns,fulvarnms,graphdata){
  if(!dir.exists(graphdir)){dir.create(graphdir)}
  outgraphdir <- paste(graphdir,"/MonthlyChange",sep="")
  if(!dir.exists(outgraphdir)){dir.create(outgraphdir)}
  for(i_var in 1:length(varnms)){
    varnm <- varnms[i_var]
    if(varnm == "prcp"){
      fvarnm <- fulvarnms[3]
    } else if(varnm == "tmax"){
      fvarnm <- fulvarnms[2]
    } else if(varnm == "tmin"){
      fvarnm <- fulvarnms[1]
    }
    for(i_stn in 1:length(stnnms)){
      stnnm <- stnnms[i_stn]
      for(i_fut in 1:length(futscns)){
        futscn <- futscns[i_fut]
        outdat <- graphdata[[varnm]][[stnnm]][[futscn]]
        tempmin <- min(outdat[,"Min"])
        tempmax <- max(outdat[,"Max"])
        if(i_stn == 1){
          tempmin1 <- tempmin
          tempmax1 <- tempmax
        } else {
          tempmin1 <- c(tempmin1,tempmin)
          tempmax1 <- c(tempmax1,tempmax)
        }
      }
    }
    Ymax <- max(tempmax1)
    Ymin <- min(tempmin1)
    for(i_stn in 1:length(stnnms)){
      g <- list()
      stnnm <- stnnms[i_stn]
      for(i_fut in 1:length(futscns)){
        futscn <- futscns[i_fut]
        outdat <- graphdata[[varnm]][[stnnm]][[futscn]]
        titlenm <- paste("Monthly Change(Range) ",futscn," ",fvarnm," Boxplot",sep="")
        g[[i_fut]] <- ggplot(data=outdat, aes(x=Month,y=Mean,col=Categori)) +
          geom_ribbon(aes(ymin=Min, ymax=Max,fill=Categori),alpha=0.3,colour=NA) +
          geom_line(size=1,alpha=0.7) + labs(y=fvarnm,title=titlenm) +
          scale_x_continuous(breaks = seq(1,12,1)) +
          coord_cartesian(ylim = c(Ymin,Ymax)) +
          theme(legend.position = "bottom",panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                plot.title = element_text(hjust=0.5))
      }

      pngnm <- paste(outgraphdir,"/",varnm,"_",stnnm,"_MonthlyChange.png",sep="")
      gg <- grid.arrange(g[[1]],g[[2]],g[[3]],g[[4]],ncol=2)
      ggsave(gg,filename = pngnm,width = 11,height = 11)
    }
  }
}
