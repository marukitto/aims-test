Cal.ClimateChangeData <- function(sel_gcmnms,VarNames,stndir,stnfile,CCSmrDir,syear_his,eyear_his,
                              syear_scn,eyear_scn,syear_obs,eyear_obs,rcpnms,DsDir,sel_dsnms,smon,emon,...){
  gcmnms = sel_gcmnms
  ## Convert VarNames to varnms
  variovar <- NA
  if("pr" %in% VarNames) variovar <- c(variovar,"prcp")
  if("tasmax" %in% VarNames) variovar <- c(variovar, "tmax")
  if("tasmin" %in% VarNames) variovar <- c(variovar, "tmin")
  variovar <- variovar[-1]
  CCSmrdir <- CCSmrDir
  stninfo <- read.csv(paste(stndir,"/",stnfile,sep=""))
  stnnms <- stninfo[,"ID"]
  if(!dir.exists(CCSmrdir)){dir.create(CCSmrdir)}
  outdir <- paste(CCSmrdir,"/Raw",sep="")
  if(!dir.exists(outdir)){dir.create(outdir)}
  #########################################################################
  #####                         Station Summary                      ######
  #########################################################################

  #################################################
  ########## Historical Summary ###################
  if(smon <= emon){
    for(i_ds in 1:length(sel_dsnms)){
      dsnm <- sel_dsnms[i_ds]
      dsdir <- paste(DsDir,"/",dsnm,sep="")
      outputdir <- paste(outdir,"/",dsnm,sep="")
      if(!dir.exists(outputdir)){dir.create(outputdir)}
      for(i_var in 1:length(variovar)){
        varnm <- variovar[i_var]
        for(i_stn in 1:length(stnnms)){
          stnnm <- stnnms[i_stn]
          obsfdir <- file.path(DsDir,"OBS",sprintf("%s_observed.csv", stnnm))
          obs <- read.csv(obsfdir) %>% filter(mon >= smon, mon <= emon, year >= syear_obs, year <= eyear_obs) %>%
            select_(.dots = list("year","mon","day",varnm))
          colnames(obs) <- c("year","mon","day","value")
          if(varnm == "prcp"){
            mon_obs <- obs %>% group_by(mon) %>% summarise(mon_val = sum(value, na.rm=T) / length(unique(year)))
          } else {
            mon_obs <- obs %>% group_by(mon) %>% summarise(mon_val = mean(value, na.rm=T))
          }
          colnames(mon_obs) <- c("month","Observed")

          for(i_gcm in 1:length(gcmnms)){
            gcmnm <- gcmnms[i_gcm]
            histfdir <- file.path(dsdir,gcmnm,sprintf("%s_%s_%s_historical.csv",stnnm,dsnm,gcmnm))
            sim <- read.csv(histfdir) %>% filter(mon >= smon, mon <= emon, year >= syear_obs, year <= eyear_obs) %>%
              select_(.dots = list("year","mon","day",varnm))
            colnames(sim) <- c("year","mon","day","value")
            if(varnm == "prcp"){
              mon_sim <- sim %>% group_by(mon) %>% summarise(mon_val = sum(value, na.rm=T) / length(unique(year)))
            } else {
              mon_sim <- sim %>% group_by(mon) %>% summarise(mon_val = mean(value, na.rm=T))
            }
            colnames(mon_sim) <- c("month",gcmnm)
            if(i_gcm == 1){
              sim_tbl <- mon_sim
            } else {
              sim_tbl <- merge(sim_tbl, mon_sim, by="month")
            }
          } # gcm

          sim_tbl <- select(sim_tbl,gcmnms)
          smry <- as.data.frame(t(apply(sim_tbl,1,summary)))

          out_tbl <- cbind(mon_obs, sim_tbl, smry)
          colsum <- colSums(out_tbl)
          out_tbl <- rbind(out_tbl, colsum)
          out_tbl$month <- c(smon:emon, "Sum/Avg")

          outdfile <- file.path(outputdir,
                                sprintf("%s_%s_Repro_SY%dEY%d_SM%02dEM%02d.csv",
                                        varnm, stnnm, syear_his, eyear_his, smon, emon))
          write.csv(out_tbl, outdfile, row.names = F)
        } #stn
      } #var
    } #dsnm
  } else {
    print(paste("Start Month is bigger then End Month"))
  }


  #################################################
  ########## Future Summary ###################
  #################################################
  if(smon <= emon){
    for(i_ds in 1:length(sel_dsnms)){
      dsnm <- sel_dsnms[i_ds]
      dsdir <- paste(DsDir,"/",dsnm,sep="")
      outputdir <- paste(outdir,"/",dsnm,sep="")
      if(!dir.exists(outputdir)){dir.create(outputdir)}
      for(i_var in 1:length(variovar)){
        varnm <- variovar[i_var]
        cat(paste("Now... Monthly Future summary Variable ",varnm," is running..",sep=""));cat("\n")
        pb <- txtProgressBar(min = 0, max =length(stnnms), initial = 0, char = "=", style = 3)
        for(i_stn in 1:length(stnnms)){
          setTxtProgressBar(pb, i_stn)
          stnnm <- stnnms[i_stn]
          histfdir <- file.path(outputdir,
                                sprintf("%s_%s_Repro_SY%dEY%d_SM%02dEM%02d.csv",
                                        varnm, stnnm, syear_his, eyear_his, smon, emon))
          hist <- read.csv(histfdir) %>% filter(as.numeric(month) >= smon, as.numeric(month) <= emon) %>%
            select(month,Mean)
          colnames(hist) <- c("month","Historical_Mean")

          for(i_rcp in 1:length(rcpnms)){
            rcpnm <- rcpnms[i_rcp]
            for(i_fut in 1:length(syear_scn)){
              futsyear <- syear_scn[i_fut]
              futeyear <- eyear_scn[i_fut]
              for(i_gcm in 1:length(gcmnms)){
                gcmnm <- gcmnms[i_gcm]
                futfdir <- file.path(dsdir,gcmnm,sprintf("%s_%s_%s_%s.csv",stnnm,dsnm,gcmnm,rcpnm))
                sim <- read.csv(futfdir) %>% filter(mon >= smon, mon <= emon, year >= futsyear, year <= futeyear) %>%
                  select_(.dots = list("year","mon","day",varnm))
                simyear <- unique(sim$year)
                testyear <- seq(2092,2099,1)
                if(rcpnm == "rcp85" & sum(simyear %in% testyear) >= 1 & gcmnm == "HadGEM2-ES" & varnm == "tmin"){
                  st <- which(sim$year == 2092 & sim$mon == 12 & sim$day == 1)
                  ed <- nrow(sim)
                  sim[st:ed,"tmin"] <- NA
                }
                colnames(sim) <- c("year","mon","day","value")

                if(varnm == "prcp"){
                  mon_sim <- sim %>% group_by(mon) %>% summarise(mon_val = sum(value, na.rm=T) / length(unique(year)))
                } else {
                  mon_sim <- sim %>% group_by(mon) %>% summarise(mon_val = mean(value, na.rm=T))
                }
                colnames(mon_sim) <- c("month",gcmnm)
                if(i_gcm == 1){
                  sim_tbl <- mon_sim
                } else {
                  sim_tbl <- merge(sim_tbl, mon_sim, by="month")
                }
              } # gcm
              sim_tbl <- select(sim_tbl,gcmnms)
              smry <- as.data.frame(t(apply(sim_tbl,1,summary)))

              out_tbl <- cbind(hist, sim_tbl, smry)
              out_tbl$month <- seq(smon:emon)
              colsum <- colSums(out_tbl)
              out_tbl <- rbind(out_tbl, colsum)
              out_tbl$month <- c(smon:emon, "Sum/Avg")

              outdfile <- file.path(outputdir,
                                    sprintf("%s_%s_Future%02d_%s_SY%dEY%d_SM%02dEM%02d.csv",
                                            varnm, stnnm, i_fut, rcpnm, futsyear, futeyear, smon, emon))
              write.csv(out_tbl, outdfile, row.names = F)
            } #fut
          } #rcp
        } #stn
        close(pb)
      } #var
    } #dsnm
  } else {
    print(paste("Start Month is bigger then End Month"))
  }


  #################################################
  ########## Annual Summary ###################
  #################################################
  futsyear <- syear_scn[1]
  futeyear <- eyear_scn[length(eyear_scn)]
  if(smon <= emon){
    for(i_ds in 1:length(sel_dsnms)){
      dsnm <- sel_dsnms[i_ds]
      dsdir <- paste(DsDir,"/",dsnm,sep="")
      outputdir <- paste(outdir,"/",dsnm,sep="")
      if(!dir.exists(outputdir)){dir.create(outputdir)}
      for(i_var in 1:length(variovar)){
        varnm <- variovar[i_var]
        cat(paste("Now... Annual summary Variable ",varnm," is running..",sep=""));cat("\n")
        pb <- txtProgressBar(min = 0, max =length(stnnms), initial = 0, char = "=", style = 3)
        for(i_stn in 1:length(stnnms)){
          setTxtProgressBar(pb, i_stn)
          stnnm <- stnnms[i_stn]
          obsfdir <- file.path(DsDir,"OBS",sprintf("%s_observed.csv", stnnm))
          obs <- read.csv(obsfdir) %>% filter(mon >= smon, mon <= emon, year >= syear_obs, year <= eyear_obs) %>%
            select_(.dots = list("year","mon","day",varnm))
          colnames(obs) <- c("year","mon","day","value")
          if(varnm == "prcp"){
            year_obs <- obs %>% group_by(year) %>% summarise(mon_val = sum(value, na.rm=T))
          } else {
            year_obs <- obs %>% group_by(year) %>% summarise(mon_val = mean(value, na.rm=T))
          }
          colnames(year_obs) <- c("Year","Observed")
          OutDFile <- file.path(outputdir, sprintf("%s_%s_Annual_Observed.csv", varnm, stnnm))
          write.csv(year_obs, OutDFile, row.names = F)
          for(i_gcm in 1:length(gcmnms)){
            gcmnm <- gcmnms[i_gcm]
            histfdir <- file.path(dsdir,gcmnm,sprintf("%s_%s_%s_historical.csv",stnnm,dsnm,gcmnm))
            sim <- read.csv(histfdir) %>% filter(year >= syear_obs, year <= eyear_obs) %>%
              select_(.dots = list("year","mon","day",varnm))
            colnames(sim) <- c("year","mon","day","value")
            if(varnm == "prcp"){
              year_sim <- sim %>% group_by(year) %>% summarise(mon_val = sum(value, na.rm=T))
            } else {
              year_sim <- sim %>% group_by(year) %>% summarise(mon_val = mean(value, na.rm=T))
            }
            colnames(year_sim) <- c("Year",gcmnm)
            if(i_gcm == 1){
              sim_tbl <- year_sim
            } else {
              sim_tbl <- merge(sim_tbl, year_sim, by="Year")
            }
          } # gcm

          sim_imsi <- select(sim_tbl, gcmnms)
          smry <- as.data.frame(t(apply(sim_imsi,1,summary)))

          out_tbl <- cbind(sim_tbl, smry)

          OutDFile <- file.path(outputdir, sprintf("%s_%s_Annual_Historical.csv", varnm, stnnm))
          write.csv(out_tbl, OutDFile, row.names = F)

          for(i_rcp in 1:length(rcpnms)){
            rcpnm <- rcpnms[i_rcp]

            for(i_gcm in 1:length(gcmnms)){
              gcmnm <- gcmnms[i_gcm]
              futfdir <- file.path(dsdir,gcmnm,sprintf("%s_%s_%s_%s.csv",stnnm,dsnm,gcmnm,rcpnm))
              sim <- read.csv(futfdir) %>% filter(year >= futsyear, year <= futeyear) %>%
                select_(.dots = list("year","mon","day",varnm))
              simyear <- unique(sim$year)
              testyear <- seq(2092,2099,1)
              if(rcpnm == "rcp85" & sum(simyear %in% testyear) >= 1 & gcmnm == "HadGEM2-ES" & varnm == "tmin"){
                st <- which(sim$year == 2092 & sim$mon == 12 & sim$day == 1)
                ed <- nrow(sim)
                sim[st:ed,"tmin"] <- NA
              }
              colnames(sim) <- c("year","mon","day","value")
              if(varnm == "prcp"){
                year_sim <- sim %>% group_by(year) %>% summarise(mon_val = sum(value, na.rm=T))
              } else {
                year_sim <- sim %>% group_by(year) %>% summarise(mon_val = mean(value, na.rm=T))
              }
              colnames(year_sim) <- c("Year",gcmnm)
              if(i_gcm == 1){
                sim_tbl <- year_sim
              } else {
                sim_tbl <- merge(sim_tbl, year_sim, by="Year")
              }
            } # gcm
            sim_imsi <- select(sim_tbl,gcmnms)
            if(rcpnm == "rcp85" & sum(gcmnms %in% "HadGEM2-ES") >= 1 & varnm == "tmin"){
              smry <- as.data.frame(list.rbind(apply(sim_imsi,1,summary)))
              smry <- smry[,-ncol(smry)]
            } else {
              smry <- as.data.frame(t(apply(sim_imsi,1,summary)))
            }
            out_tbl <- cbind(sim_tbl, smry)

            outdfile <- file.path(outputdir, sprintf("%s_%s_Annual_%s.csv", varnm, stnnm, rcpnm))
            write.csv(out_tbl, outdfile, row.names = F)
          } #rcp
        } #stn
        close(pb)
      } #var
    } #dsnm
  } else {
    print(paste("Start Month is bigger then End Month"))
  }

}


