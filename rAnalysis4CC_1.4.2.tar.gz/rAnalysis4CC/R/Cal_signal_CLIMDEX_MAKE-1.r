get_index_value <- function(idxnm, ci) {
  switch(idxnm,
    su={
      return(matrix(climdex.su(ci),nrow=1,ncol=length(climdex.su(ci))))
    },
    id={
      return(matrix(climdex.id(ci),nrow=1,ncol=length(climdex.id(ci))))
    },
    txn={
      TXn_idx_month=climdex.txn(ci)
      data=matrix(ncol=length(TXn_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=min(TXn_idx_month[start:end])
      }
      return(data)
    },
    txx={
      TXx_idx_month=climdex.txx(ci)
      data=matrix(ncol=length(TXx_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=max(TXx_idx_month[start:end])
      }
      return(data)
    },
    tx10p={
      TX10p_idx_month=climdex.tx10p(ci)
      data=matrix(ncol=length(TX10p_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=mean(TX10p_idx_month[start:end])
      }
      return(data)
    },
    tx90p={
      TX90p_idx_month=climdex.tx90p(ci)
      data=matrix(ncol=length(TX90p_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=mean(TX90p_idx_month[start:end])
      }
      return(data)
    },
    wsdi={
      return(matrix(climdex.wsdi(ci),nrow=1,ncol=length(climdex.wsdi(ci))))
    },
    fd={
      return(matrix(climdex.fd(ci),nrow=1,ncol=length(climdex.fd(ci))))
    },
    tr={
      return(matrix(climdex.tr(ci),nrow=1,ncol=length(climdex.tr(ci))))
    },
    tnn={
      TNn_idx_month=climdex.tnn(ci)
      data=matrix(ncol=length(TNn_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=min(TNn_idx_month[start:end])
      }
      return(data)
    },
    tnx={
      TNx_idx_month=climdex.tnx(ci)
      data=matrix(ncol=length(TNx_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=max(TNx_idx_month[start:end])
      }
      return(data)
    },
    tn10p={
      TN10p_idx_month=climdex.tn10p(ci)
      data=matrix(ncol=length(TN10p_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=mean(TN10p_idx_month[start:end])
      }
      return(data)
    },
    tn90p={
      TN90p_idx_month=climdex.tn90p(ci)
      data=matrix(ncol=length(TN90p_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=mean(TN90p_idx_month[start:end])
      }
      return(data)
    },
    csdi={
      return(matrix(climdex.csdi(ci),nrow=,ncol=length(climdex.csdi(ci))))
    },
    dtr={
      dtr_idx_month=climdex.dtr(ci)
      data=matrix(ncol=length(dtr_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]=mean(dtr_idx_month[start:end])
      }
      return(data)
    },
    gsl={
      return(matrix(climdex.gsl(ci),nrow=1,ncol=length(climdex.gsl(ci))))
    },
    prcptot={
      return(matrix(climdex.prcptot(ci),nrow=1,ncol=length(climdex.prcptot(ci))))
    },
    cdd={
      return(matrix(climdex.cdd(ci),nrow=1,ncol=length(climdex.cdd(ci))))
    },
    cwd={
      return(matrix(climdex.cwd(ci),nrow=1,ncol=length(climdex.cwd(ci))))
    },
    r95ptot={
      return(matrix(climdex.r95ptot(ci),nrow=1,ncol=length(climdex.r95ptot(ci))))
    },
    r99ptot={
      return(matrix(climdex.r99ptot(ci),nrow=1,ncol=length(climdex.r99ptot(ci))))
    },
    rx1day={
      rx1day_idx_month=climdex.rx1day(ci)
      data=matrix(ncol=length(rx1day_idx_month)/12)
      for (I_Year in 1:length(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]<-max(rx1day_idx_month[start:end])
      }
      return(data)
    },
    rx5day={
      rx5day_idx_month=climdex.rx5day(ci)
      data=matrix(ncol=length(rx5day_idx_month)/12)
      for (I_Year in 1:ncol(data)) {
        start<-(I_Year-1)*12+1
        end<-(I_Year-1)*12+12
        data[I_Year]<-max(rx5day_idx_month[start:end])
      }
      return(data)
    },
    sdii={
      return(matrix(climdex.sdii(ci),nrow=1,ncol=length(climdex.sdii(ci))))
    },
    rnnmm={
      return(matrix(climdex.rnnmm(ci),nrow=1,ncol=length(climdex.rnnmm(ci))))
    },
    r10mm={
      return(matrix(climdex.r10mm(ci),nrow=1,ncol=length(climdex.r10mm(ci))))
    },
    r20mm={
      return(matrix(climdex.r20mm(ci),nrow=1,ncol=length(climdex.r20mm(ci))))
    }
  )
  return(matrix())
}

#' @export
CLIMDEX.MAKE <- function(idxnms,ci,First_Yr,End_Yr, Custom_Functions=c(), ...){
  out <- rbind()
  for (idxnm in idxnms) {
    out <- rbind(out, get_index_value(idxnm, ci))
    rownames(out) <- c(head(rownames(out), -1), idxnm)
  }

  # try custom custom functions
  index <- ci@date.factors$annual
  tmax <- ci@data$tmax
  tmin <- ci@data$tmin
  tavg <- ci@data$tavg
  prec <- ci@data$prec

  for (name in names(Custom_Functions)) {
    v <- Custom_Functions[[name]](index, tmax, tmin, tavg, prec)
    out <- rbind(out, v)
    rownames(out) <- c(head(rownames(out), -1), name)
    idxnms <- c(idxnms, name)
  }

  year <- seq(First_Yr,End_Yr,1)
  return(rbind(year,out[which(apply(out,1,mean,na.rm=TRUE)!=-999),]))
}
