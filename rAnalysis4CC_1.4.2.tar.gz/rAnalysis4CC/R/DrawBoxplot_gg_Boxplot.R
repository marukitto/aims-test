#' @export
gg.boxplot <- function(X,fname,idxnm,dsnms){

  #nms <- as.character(unique(X[,"Downscaling"]))
  #rcps <- as.character(unique(X[,"RCP"]))
  #futs <- as.character(unique(X[,"Future"]))
  nms <- unique(X[,"Downscaling"])
  rcps <- unique(X[,"RCP"])
  futs <- unique(X[,"Future"])
  tblmat1 <- tblmat2 <- matrix(NA,6,(length(nms)*length(futs)))
  colnmmat <- matrix(NA,1,(length(nms)*length(futs)))
  titleidx <- find.fullidxnm(idxnm)
  for(i_rcp in 1:length(rcps)){
    wh <- which(X[,"RCP"] == rcps[i_rcp])
    TEMP <- X[wh,]
    k <- 1
    for(i_fut in 1:length(futs)){
      wh1 <- which(TEMP[,"Future"]==futs[i_fut])
      TEMP1 <- TEMP[wh1,]
      for(i_dsnm in 1:length(dsnms)){
        if(i_rcp == 1){
          wh2 <- which(TEMP1[,"Downscaling"]==dsnms[i_dsnm])
          temp2 <- TEMP1[wh2,"Error"]
          for(j in 1:6){
            tblmat1[j,k] <- round(summary(temp2)[j],2)
          }
          colnmmat[1,k] <- paste(dsnms[i_dsnm],substr(futs[i_fut],1,2),sep=" ")
          k <- k + 1
        } else {
          wh2 <- which(TEMP1[,"Downscaling"]==dsnms[i_dsnm])
          temp2 <- TEMP1[wh2,"Error"]
          for(j in 1:6){
            tblmat2[j,k] <- round(summary(temp2)[j],2)
          }
          k <- k + 1
        }
      }
    }
  }
  rownames(tblmat1) <- rownames(tblmat2) <- c(names(summary(temp2)))
  colnames(tblmat1) <- colnames(tblmat2) <- c(colnmmat)
  if(length(dsnms) == 1){
    widths <- 0.5
  } else if(length(dsnms)==2){
    if(length(rcps)==1){
      if(length(futs) == 1){
        widths <- 0.5
      } else if(length(futs) == 2){
        widths <- 2
      } else if(length(futs) == 3){
        widths <- 3
      }
    } else if(length(rcps)==2){
      if(length(futs) == 1){
        widths <- 1
      } else if(length(futs) == 2){
        widths <- 2
      } else if(length(futs) == 3){
        widths <- 3
      }
    }
  }

  #ifelse(length(nms)==1,widths <- 0.5,widths<-4)
  p = ggplot() + facet_grid(RCP ~ Future, scales = "free", space="free_x") +
    #geom_boxplot(data=X,width=widths, aes(x=factor(Downscaling, levels=unique(Downscaling)),y=Error)) +
    geom_boxplot(data=X, aes(x=factor(Downscaling, levels=unique(Downscaling)),y=Error)) +
    theme(axis.text.x=element_text(size=rel(1.2),angle = 90, vjust = 0, hjust=1, colour="black"),
          axis.text.y=element_text(size=rel(1.2),colour="black"),
          axis.title.x=element_blank(),
          axis.title.y=element_blank(),strip.text = element_text(size=11),
          plot.title=element_text(size=18,hjust=0.5),panel.grid.major = element_blank(),
          panel.grid.minor = element_blank()) +
    geom_hline(yintercept=0,color="red")+
    ggtitle(paste("Signal Diff.(DS-Raw) of ",titleidx[1],":",titleidx[2]," (",titleidx[3],")",sep=""))

  stable1 <- ggtexttable(tblmat1,theme=ttheme(base_size = 10,colnames.style = colnames_style(fill="white")))
  text1 <- paste("Summary Table of ",rcps[1],sep="")
  text1.p <- ggparagraph(text = text1, face="italic", size = 12, color = "black")
  if(length(rcps)==2){
    stable2 <- ggtexttable(tblmat2,theme=ttheme(base_size = 10,colnames.style = colnames_style(fill="white")))
    text2 <- paste("Summary Table of ",rcps[2],sep="")
    text2.p <- ggparagraph(text = text2, face="italic", size = 12, color = "black")
  }

  # A helper function to define a region on the layout
  define_region <- function(row, col){
    viewport(layout.pos.row = row, layout.pos.col = col)
  }

  if(length(dsnms) <= 2){
    if(length(rcps)==1){
      png(fname,width=750,height=750)
      grid.newpage()
      # Create layout
      pushViewport(viewport(layout = grid.layout(nrow = 100, ncol = 100)))
      # Arrange the plots
      print(p, vp = define_region(row = 2:70, col = 5:95))   # Span over two columns
      print(text1.p, vp=define_region(row=74:75, col = 40:60))
      print(stable1, vp = define_region(row = 77:95, col = 20:80))
      #print(tests.p, vp = define_region(row = 6.5, col = 8))
      dev.off()
    } else {
      png(fname,width=750,height=750)
      grid.newpage()
      # Create layout
      pushViewport(viewport(layout = grid.layout(nrow = 31, ncol = 100)))
      # Arrange the plots
      if(length(nms)==1){
        print(p, vp = define_region(row = 2:22, col = 4:96))   # Span over two columns
        print(stable1, vp = define_region(row = 24:29, col = 8:48))
        print(stable2, vp = define_region(row = 24:29, col = 55:95))
        print(text1.p, vp=define_region(row=24:25, col = 6:16))
        print(text2.p, vp=define_region(row=24:25, col = 53:63))
      } else {
        print(p, vp = define_region(row = 2:18, col = 4:96))   # Span over two columns
        print(stable1, vp = define_region(row = 19:24, col = 20:90))
        print(stable2, vp = define_region(row = 25:30, col = 20:90))
        print(text1.p, vp=define_region(row=21:22, col = 12:22))
        print(text2.p, vp=define_region(row=27:28, col = 12:22))
      }
      dev.off()
    }
  } else if(length(dsnms) == 3){
    if(length(rcps)==1){
      png(fname,width=750,height=750)
      grid.newpage()
      # Create layout
      pushViewport(viewport(layout = grid.layout(nrow = 100, ncol = 100)))
      # Arrange the plots
      print(p, vp = define_region(row = 2:70, col = 5:95))   # Span over two columns
      print(text1.p, vp=define_region(row=74:75, col = 40:60))
      print(stable1, vp = define_region(row = 77:95, col = 20:80))
      #print(tests.p, vp = define_region(row = 6.5, col = 8))
      dev.off()
    } else {
      png(fname,width=750,height=750)
      grid.newpage()
      # Create layout
      pushViewport(viewport(layout = grid.layout(nrow = 31, ncol = 100)))
      # Arrange the plots
      print(p, vp = define_region(row = 2:18, col = 4:96))   # Span over two columns
      print(stable1, vp = define_region(row = 19:24, col = 20:90))
      print(stable2, vp = define_region(row = 25:30, col = 20:90))
      print(text1.p, vp=define_region(row=21:22, col = 4:14))
      print(text2.p, vp=define_region(row=27:28, col = 4:14))
      dev.off()
    }
  }


}
