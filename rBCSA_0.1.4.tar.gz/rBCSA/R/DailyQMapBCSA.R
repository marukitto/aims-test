#' @title Quantile mapping bias-correction
#'
#' @description Do bias-correction using quantile mapping ans save the bias-corrected outputs for each weather station.
#'
#' @param stndir directory path for station information file
#' @param stnfile file name for station information
#' @param qmapdir directory path for bias-corrected output files
#' @param prjdir directory path for project
#' @param SimAll logical. TRUE then process goes over all the senarios available
#' @param RcpNames Rcp names to be uses such as rcp45, rcp85
#' @param FixedVarNames variable to be used such as prcp(precipitation), tmax/tmin, solor radiation, wind etc
#' @param syear_obs start year of observation data
#' @param eyear_obs end year of observation data
#' @param syear_his start year of historical period
#' @param eyear_his end year of historical period
#' @param syear_scn start year of climate change scenario
#' @param eyear_scn end year of climate change scenario
#' @param OWrite Flag for overwriting output files (T: Overwrite, F: Skip)
#' @param SRadiation Flag for calculating solar radiation (T: Calculate, F: Skip)
#'
#' @examples
#' \dontrun{
#' ## Step 0. Load sample project
#' rSQMSampleProject()
#'
#' ## Step 1. Set working environment
#' EnvList <- SetWorkingEnvironment(envfile = "rSQM.yaml")
#'
#' ## Step 2. Load climate scenario data
#' LoadCmip5DataFromAdss(dbdir = EnvList$dbdir, NtlCode = EnvList$NtlCode)
#'
#' ## Step 3. Extract daily time series
#' DailyExtractAll(
#' cmip5dir = EnvList$cmip5dir,
#' stndir = EnvList$stndir,
#' stnfile = EnvList$stnfile,
#' qmapdir = EnvList$qmapdir,
#' SimAll = EnvList$SimAll,
#' ModelNames = EnvList$ModelNames,
#' RcpNames = EnvList$RcpNames,
#' FixedVarNames = EnvList$FixedVarNames,
#' OWrite = EnvList$OWrite)
#'
#' ## Step 4. Bias-correction by simple quantile mapping
#' DailyQMapAll(
#'   stndir = EnvList$stndir,
#'   stnfile = EnvList$stnfile,
#'   qmapdir = EnvList$qmapdir,
#'   prjdir = EnvList$prjdir,
#'   SimAll = EnvList$SimAll,
#'   RcpNames = EnvList$RcpNames,
#'   FixedVarNames = EnvList$FixedVarNames,
#'   syear_obs = EnvList$syear_obs,
#'   eyear_obs = EnvList$eyear_obs,
#'   syear_his = EnvList$syear_his,
#'   eyear_his = EnvList$eyear_his,
#'   syear_scn = EnvList$syear_scn,
#'   eyear_scn = EnvList$eyear_scn,
#'   OWrite = EnvList$OWrite,
#'   SRadiation = EnvList$SRadiation)
#' }
#' @return NULL
#' @export
#'
#'
DailyQMapAll <- function(stndir, stnfile, qmapdir, prjdir, SimAll, RcpNames, FixedVarNames, syear_obs, Cmip5Names,
                         CordexNames, eyear_obs, syear_his, eyear_his, syear_scn, eyear_scn, OWrite, SRadiation,...) {

  FixedVarNamesAll <- c('prcp','tmax','tmin', 'wspd', 'rhum', 'rsds')

  # if(SimAll){
  #   varnms <- c("prcp", "tmax", "tmin", "wspd", "rhum", "rsds")
  #   scnnms <- c('historical', 'rcp26', 'rcp45', 'rcp60', 'rcp85')
  # } else {
    ### CORDEX ###
    LocNum <- grep(paste(FixedVarNames, collapse = "|"), FixedVarNamesAll)
    varnms <- FixedVarNamesAll[LocNum]
    scnnms <- unique(c('historical', RcpNames))
  # }

  # Observed output folder
  obsoutdir <- file.path(prjdir, "Downscale", "OBS")
  if(!dir.exists(obsoutdir)){dir.create(obsoutdir)}
  # unlink(obsoutdir, recursive = T)
  # SetWorkingDir(obsoutdir)

  varcnt <- length(varnms)
  scncnt <- length(scnnms)

  ###### Get Station ID, lat, and Lon information
  stninfo <- read.csv(file.path(stndir, stnfile), header=T)
  stninfo <- stninfo[,c("ID", "Lon", "Lat")]
  stnnms <- matrix(stninfo$ID)
  stncnt <- length(stnnms)

  WriteOBSdata(stnnms,stndir,obsoutdir,SRadiation,syear_obs,eyear_obs)

  ###### Get model names
  #ModelNames <- list.dirs(qmapdir, recursive = F)
  #Model_Matrix <- matrix(unlist(strsplit(ModelNames, "/")), nrow=length(ModelNames), byrow=T)
  #ModelNames <- Model_Matrix[,ncol(Model_Matrix)]
  ModelNames <- unique(c(Cmip5Names,CordexNames))
  Model_Cnt <- length(ModelNames)


  for (mm in 1:Model_Cnt) {

    Model_Name <- ModelNames[mm]

    indir <- file.path(qmapdir, Model_Name, '365adj')
    outdir <- file.path(qmapdir, Model_Name)
    print(paste("Now ",Model_Name," is running now...",sep=""))
    DailyBCSA(Model_Name, indir, qmapdir, outdir, obsoutdir, prjdir, stnnms, syear_his, eyear_his, syear_scn, eyear_scn,OWrite)

    # Delete 365adj folders
    #adjnm <- file.path(qmapdir, Model_Name, "365adj")
    #unlink(adjnm, recursive = T)

  } # Model Loop

}
