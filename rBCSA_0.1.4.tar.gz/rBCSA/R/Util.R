# stnids <- stnnms
# varnms <- varnms
# scnnm <- scnnms[1]
# indir <- indir
# Model_Name <- Model_Name

WriteOBSdata <- function(stnnms,stndir,obsoutdir,SRadiation,syear_obs,eyear_obs){
  cat(paste("Writing OBS... process now..."));cat("\n")
  pb <- txtProgressBar(min=1,max=length(stnnms),style=3)
  for(i_STN in 1:length(stnnms)){
    setTxtProgressBar(pb,i_STN)
    stnid <- stnnms[i_STN]
    obsdata <- ReadObsData(stnid, stndir)  #read obs data(read -99.0 as NA)
    colnames(obsdata) <- c("year", "mon", "day", "yearmon", "date", "prcp", "tmax", "tmin", "wspd", "rhum", "rsds")
    if(SRadiation){
      obsdata <- CalSradiation(obsdata, stnid, stndir, stnfile)
    }
    obsdata[is.na(obsdata)] <- -99
    st <- min(which(obsdata[,"year"]==syear_obs))
    ed <- max(which(obsdata[,"year"]==eyear_obs))
    out <- obsdata[st:ed,c("year", "mon", "day","prcp", "tmax", "tmin", "wspd", "rhum", "rsds")]
    outfile <- file.path(obsoutdir, paste(stnid, "_observed.csv", sep=""))
    write.csv(out,outfile,row.names = F)
  }
  close(pb)
}


GetSameStationInfo <- function(data){
  X <- data[,2:ncol(data)]
  stnnms <- colnames(X)
  temp <- X
  tempnm <- stnnms
  out <- list()
  i <- 1
  for(i in 1:ncol(data)){
    if(length(tempnm)==1){
      out[[i]] <- tempnm
      tempnm <- tempnm[-1]
    } else {
      temp1 <- temp - temp[,1]
      resul <- apply(temp1,2,sum,na.rm=T)
      wh <- which(resul==0)
      out[[i]] <- tempnm[wh]
      temp <- temp[,-wh]
      tempnm <- tempnm[-wh]
    }
    if(length(tempnm)==0){
      break
    }
  }
  return(out)
}


FindMinErrorMats <- function(X,Y){
  if(ncol(X)==ncol(Y)){
    for(i_col in 1:ncol(X)){
      if(i_col==1){
        tempdat <- rep(Y[,i_col],nrow(X))
      } else {
        tempdat <- cbind(tempdat,rep(Y[,i_col],nrow(X)))
      }
    }
    #X - t(matrix(rep(Y, nrow(X)), ncol(Y)))
    tempmean <- apply((X - tempdat)^2,1,mean)
    Whmin <- which(tempmean == min(tempmean))
    if(length(Whmin)==1){
      return(Whmin)
    } else {
      return(sample(Whmin,1))
    }
    # for(i_row in 1:nrow(X)){
    #   if(i_row==1){
    #     result <- sum((X[i_row,] - Y)^2)
    #   } else {
    #     result <- c(result,sum((X[i_row,] - Y)^2))
    #   }
    # }
    # WhMin <- which(result == min(result))
    # return(WhMin[1])
  } else {
    return(print("X, Y's dim are different"))
  }

}


FindMinErrorMaxCor <- function(vari,Fullgrid,stnnms,NumOfFull,StnLists,CorrMat,Simgrid,FullGdata,Simdata,...){
  ##Make Quantile Mapping Result Matrix
  OutMat <- matrix(0,nrow(Fullgrid),length(stnnms))
  TempFullgrid <- FullGdata
  ##Replace Simulation Result to Quantile Mapping Result with out 0 data
  cat(paste("Matching ", vari,"... process now...",sep=""));cat("\n")
  pb <- txtProgressBar(min=1,max=length(NumOfFull),style=3)
  for(i_whA in 1:length(NumOfFull)){
    whA <- NumOfFull[i_whA]
    if(length(StnLists) > 1){ #selected grids are more then 1
      if(vari == "prcp"){
        whnonzero <- which(TempFullgrid[whA,] != 0 )
        colseq <- seq(1,ncol(Simgrid))[-whnonzero] #find which col is 0
        if(length(whnonzero)==1){ #calculate with whnonzero length is 1 (this case can't use apply)
          tempgrid <- abs(TempFullgrid[whA,whnonzero] - Simgrid[,whnonzero])
          whseleted <- which(tempgrid==min(tempgrid))
        } else {
          TempNonZeroMat <- matrix(NA,nrow(Simgrid),ncol(Simgrid))
          for(i_count in 1:ncol(Simgrid)){
            for(i_rows in 1:nrow(Simgrid)){
              if(i_count %in% whnonzero){
                TempNonZeroMat[i_rows,i_count] <- ifelse(Simgrid[i_rows,i_count]!=0,1,0)
              } else if(i_count %in% colseq){
                TempNonZeroMat[i_rows,i_count] <- 0
              }
            }
          }
          TempNonZero <- apply(TempNonZeroMat,1,sum)
          WhNoZeroRow <- which(TempNonZero==length(whnonzero))
          if(length(WhNoZeroRow) == 0){
            WhNoZeroRow <- seq(1,nrow(Simgrid),1)
          }
          Ranknumber <- ifelse(length(WhNoZeroRow)>=30,30,length(WhNoZeroRow))
          tempmseprcp <- ListMatMSE(TempFullgrid[whA,whnonzero], Simgrid[WhNoZeroRow,whnonzero])
          #RankMseprcp <- tempmseprcp[order(tempmseprcp)][1:Ranknumber]
          whseleted <- WhNoZeroRow[order(tempmseprcp)][1:Ranknumber]
        }


        if(length(whnonzero) > 1){ #non zero colunm is over then 2
          if(length(whseleted)==1){ #selected simgird row is 1
            MatchSimNum <- whseleted
          } else { #selected simgrid row is over then 2
            Simsel <- Simgrid[whseleted,whnonzero]
            Temsel <- TempFullgrid[whA,whnonzero]
            if(var(unlist(Temsel))==0){
              MaxCorPrcp <- which(ListMatMSE(Temsel,Simsel) == min(ListMatMSE(Temsel,Simsel)))
            } else {
              TempCorPrcp <- cor(t(Simsel),t(Temsel))
              if(length(TempCorPrcp) == sum(is.na(TempCorPrcp))){
                MaxCorPrcp <- which(ListMatMSE(Temsel,Simsel) == min(ListMatMSE(Temsel,Simsel)))
              } else {
                MaxCorPrcp <- which(TempCorPrcp==max(TempCorPrcp,na.rm=T))
              }
            }
            if(length(MaxCorPrcp)!=1){MaxCorPrcp <- sample(MaxCorPrcp,1)}
            MatchSimNum <- whseleted[MaxCorPrcp]
          }
        } else { #non zero colunm is only 1
          diffDsSim <- Fullgrid[whA,(whnonzero+1)] - Simgrid[whseleted,whnonzero]
          whdiffmin <- which(abs(diffDsSim) == min(abs(diffDsSim)))
          if(length(whdiffmin)==1){ #minimum value is 1
            whdiffmin <- whdiffmin
          } else { #minimum values length is over then 2
            whdiffmin <- sample(whdiffmin,1)
          }
          MatchSimNum <- whseleted[whdiffmin]
        }
        #### calculate weight value each grids with out zero
        weightedrate <- matrix(0,1,ncol(Simgrid))
        for(i_col in 1:length(whnonzero)){
          if(Simgrid[MatchSimNum,whnonzero[i_col]] == 0){
            weightedrate[1,whnonzero[i_col]] <- 0
          } else {
            weightedrate[1,whnonzero[i_col]] <- Fullgrid[whA,(whnonzero[i_col]+1)] / Simgrid[MatchSimNum,whnonzero[i_col]]
          }
        }

      } else { ###if Tmax or Tmin
        WhMaxCor <- which(CorrMat[whA,]==max(CorrMat[whA,],na.rm=T))
        MaxCorSim <- Simgrid[WhMaxCor,]
        MatchSimNum <- WhMaxCor[FindMinErrorMats(MaxCorSim,FullGdata[whA,])] #if corr max is over then 2

        #### calculate weight value each grids with out zero
        weightedrate <- matrix(0,1,ncol(Simgrid))
        for(i_col in 1:length(whnonzero)){
          if(Simgrid[MatchSimNum,whnonzero[i_col]] == 0){
            weightedrate[1,whnonzero[i_col]] <- 0
          } else {
            weightedrate[1,whnonzero[i_col]] <- Fullgrid[whA,(whnonzero[i_col]+1)] - Simgrid[MatchSimNum,whnonzero[i_col]]
          }
        }
      }

    } else { #Selected grid is 1
      WhMaxCor <- which(CorrMat[whA,]==min(CorrMat[whA,],na.rm=T))
      if(length(WhMaxCor)==1){
        MatchSimNum <- WhMaxCor
      } else {
        MatchSimNum <- sample(WhMaxCor,1)
      }
      if(vari == "prcp"){
        weightedrate <- matrix(Fullgrid[whA] / Simgrid[MatchSimNum],1,1)
      } else {
        weightedrate <- matrix(Fullgrid[whA] - Simgrid[MatchSimNum],1,1)
      }
    }

    ### Calculate Weight value of each stations
    weightmat <- matrix(-99,1,length(stnnms))
    colnames(weightmat) <- stnnms
    for(i_stn1 in 1:length(StnLists)){
      for(i_stn2 in 1:length(StnLists[[i_stn1]])){
        tstn <- StnLists[[i_stn1]][i_stn2]
        weightmat[,tstn] <- as.numeric(weightedrate[1,i_stn1])
      }
    }
    for(i_STN in 1:length(stnnms)){
      if(vari == "prcp"){
        OutMat[whA,i_STN] <- Simdata[MatchSimNum,i_STN] * weightmat[1,i_STN]
      } else {
        OutMat[whA,i_STN] <- Simdata[MatchSimNum,i_STN] + weightmat[1,i_STN]
      }
    }
    setTxtProgressBar(pb,i_whA)
  }
  close(pb)
  return(OutMat)
}

FindMinErrorMaxCorTavg <- function(vari,Fullgrid,stnnms,NumOfFull,StnLists,CorrMat,Simgrid,FullGdata,Simdata,MonOBStmax,MonOBStmin,MSEmat,...){
  ##Make Quantile Mapping Result Matrix
  OutTemp1 <- OutTemp2 <- matrix(0,nrow(Fullgrid),length(stnnms))
  OutMat <- list()
  ##Replace Simulation Result to Quantile Mapping Result with out 0 data
  cat(paste("Matching ", vari,"... process now...",sep=""));cat("\n")
  pb <- txtProgressBar(min=1,max=length(NumOfFull),style=3)
  for(i_whA in 1:length(NumOfFull)){
    whA <- NumOfFull[i_whA]
    TempMSEmat <- ListMatMSE(FullGdata[whA,],Simgrid)
    if(length(StnLists) > 1){ #selected grids are more then 1
      RankMSEmat <- TempMSEmat[order(TempMSEmat)][1:30]
      FindMSEcol <- which(TempMSEmat %in% RankMSEmat)
      TempMaxCor <- which(CorrMat[whA,FindMSEcol]==max(CorrMat[whA,FindMSEcol],na.rm=T))
      if(length(TempMaxCor)==1){
        TempMaxCor <- TempMaxCor
      } else {
        TempMaxCor <- sample(TempMaxCor,1)
      }
      WhMaxCor <- FindMSEcol[TempMaxCor]
      MaxCorSim <- Simgrid[WhMaxCor,]
      MatchSimNum <- WhMaxCor[FindMinErrorMats(MaxCorSim,FullGdata[whA,])] #if corr max is over then 2
    } else { #Selected grid is 1
      WhMaxCor <- which(CorrMat[whA,]==min(CorrMat[whA,],na.rm=T))
      if(length(WhMaxCor)==1){
        MatchSimNum <- WhMaxCor
      } else {
        MatchSimNum <- sample(WhMaxCor,1)
      }
    }

    ##find obs tmax tmin using tavg
    for(i_stn1 in 1:length(StnLists)){
      if(i_stn1 == 1){
        if(length(StnLists[[i_stn1]])==1){
          tempobsdata <- (MonOBStmax[,StnLists[[i_stn1]]] + MonOBStmin[,StnLists[[i_stn1]]]) / 2
        } else {
          tempobsdata <- apply((MonOBStmax[,StnLists[[i_stn1]]] + MonOBStmin[,StnLists[[i_stn1]]]) / 2,1,mean)
        }
      } else {
        if(length(StnLists[[i_stn1]])==1){
          tempobsdata <- cbind(tempobsdata,(MonOBStmax[,StnLists[[i_stn1]]] + MonOBStmin[,StnLists[[i_stn1]]]) / 2)
        } else {
          tempobsdata <- cbind(tempobsdata,apply((MonOBStmax[,StnLists[[i_stn1]]] + MonOBStmin[,StnLists[[i_stn1]]]) / 2,1,mean))
        }
      }
    }
    if(length(StnLists) > 1){
      tempmse <- ListMatMSE(Simgrid[MatchSimNum,],tempobsdata)
      ranktempmse <- tempmse[order(tempmse)][1:30]
      msecol <- which(tempmse %in% ranktempmse)
      tempcor <- cor(t(tempobsdata[msecol,]),t(Simgrid[MatchSimNum,]))
      whmaxcor <- which(tempcor == max(tempcor,na.rm=T))
      if(length(whmaxcor)==1){
        whmaxcor <- whmaxcor
      } else {
        whmaxcor <- sample(whmaxcor,1)
      }
      findwh <- msecol[whmaxcor]
      tempweights <- FullGdata[whA,] - tempobsdata[findwh,]
    } else {
      whmin <- which(abs(tempobsdata - Simgrid[MatchSimNum]) == min(abs(tempobsdata - Simgrid[MatchSimNum])))
      findwh <- whmin[1]
      tempweights <- FullGdata[whA,] - tempobsdata[findwh]
    }

    weightmat <- matrix(-99,1,length(stnnms))
    colnames(weightmat) <- stnnms
    for(i_stn1 in 1:length(StnLists)){
      for(i_stn2 in 1:length(StnLists[[i_stn1]])){
        tstn <- StnLists[[i_stn1]][i_stn2]
        weightmat[,tstn] <- as.numeric(tempweights[i_stn1])
      }
    }
    for(i_STN in 1:length(stnnms)){
      tempdiff <- MonOBStmax[findwh,stnnms[i_STN]] - MonOBStmin[findwh,stnnms[i_STN]]
      tempavg <- (MonOBStmax[findwh,stnnms[i_STN]] + MonOBStmin[findwh,stnnms[i_STN]]) / 2
      tempWavg <- tempavg + weightmat[,stnnms[i_STN]]
      OutTemp1[whA,i_STN] <- tempWavg + tempdiff/2
      OutTemp2[whA,i_STN] <- tempWavg - tempdiff/2
    }
    setTxtProgressBar(pb,i_whA)
  }
  close(pb)
  OutMat$tmax <- OutTemp1
  OutMat$tmin <- OutTemp2
  return(OutMat)
}

ListMatMSE <- function(X,Y){
  RepX <- t(matrix(rep(unlist(X),nrow(Y)),nrow=ncol(X),ncol = nrow(Y)))
  temp <- (Y - RepX)^2
  tempout <- apply(temp,1,mean)
  return(tempout)
}
