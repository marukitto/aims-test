GetVarLists4CORDEX <- function(CordexDir, coln) {

  #CordexDir = "F:/CORDEXDB/CORDEX_EA"; coln = 9
  
  # 1: variable names
  # 2: Region and Resolution
  # 3: GCM names
  # 4: Scenario names
  # 5: Ensemble names
  # 6: RCM names
  # 7: Version names
  # 8: Time scale
  # 9: Date information
  
  srchstr = "*.nc"
  flist = list.files(CordexDir, pattern = glob2rx(srchstr), full.names = F)
  varnm = sapply(strsplit(flist, "_"), function(x) x[[coln]])
  varnm = unique(varnm)

  return(varnm)

}
