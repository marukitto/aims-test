#' @export
Cmip5FileMatch <- function(wdir, mdlnm, rcpnm, varnm, FullNameOpt) {

  # wdir = "D:/rSQM_Test/Database/CORDEX_KR"
  # mdlnm = "HadGEM3-RA"
  # rcpnm = "rcp85"
  # varnm = "pr"
  # FullNameOpt = F
  
  mdlnm <- sprintf("%s_", mdlnm)

  toMatch <- c(varnm, mdlnm, rcpnm)

  flists = list.files(wdir, full.names = T)

  nloop = length(toMatch)

  for(i in 1:nloop){
    flists = flists[grep(toMatch[i], flists)]
  }
  
  if(FullNameOpt == F) flists <- basename(flists)
  
  return(flists)

}
