DailyBCSA <- function(Model_Name, indir, qmapdir, outdir, obsoutdir, prjdir, stnnms, syear_his, eyear_his, syear_scn, eyear_scn,OWrite){
  #Model_Name <- unique(rbindlist(strsplit(list.files(indir),"_"))[,1])
  options(warn=-1)
  scnnms <- c(as.character(unique(unlist(data.frame(strsplit(list.files(indir),"_"))[2,]))))
  varnms <- substr(unique(unlist(data.frame(strsplit(list.files(indir),"_"))[3,])),1,4)
  #scnnms <- unique(rbindlist(strsplit(list.files(indir),"_"))[,2])
  #varnms <- substr(unique(rbindlist(strsplit(list.files(indir),"_"))[,3]),1,4)
  stncnt <- length(stnnms)
  Varnms <- varnms
  if("tmax" %in% varnms & "tmin" %in% varnms){
    wh <- which(varnms == "tmax")
    varnms <- varnms[-wh]
    wh <- which(varnms == "tmin")
    varnms <- varnms[-wh]
    varnms <- c(varnms,"tavg")
  } else if("tmax" %in% varnms){
    wh <- which(varnms == "tmax")
    varnms <- varnms[-wh]
    varnms <- c(varnms,"tmax")
  } else if("tmin" %in% varnms){
    wh <- which(varnms == "tmax")
    varnms <- varnms[-wh]
    varnms <- c(varnms,"tmin")
  }
  syearall <- c(syear_his,min(syear_scn),min(syear_scn))
  eyearall <- c(eyear_his,max(eyear_scn),max(eyear_scn))
  for(i_scn in 1:length(scnnms)){
    GCMTemp <- OBSTemp <- OBSTemp1 <- OBSTemp2 <- list()
    stncnt <- length(stnnms)
    varcnt <- length(varnms)
    scnnm <- scnnms[i_scn]
    ###check file list for Overwriting
    print("CHECK FILE LISTS ALREADY EXISTS...")
    chkfnms <- list.files(outdir,glob2rx(paste("*_",scnnm,".csv",sep="")))
    if(length(chkfnms) == stncnt){
      for(i_stn in 1:length(chkfnms)){
        chkfdir <- paste(outdir,"/",chkfnms[i_stn],sep="")
        chkfdata <- read.csv(chkfdir)
        ifelse(syearall[i_scn] %in% unique(chkfdata[,"year"]) & eyearall[i_scn] %in% unique(chkfdata[,"year"]),
               TCHKPSS <- 0 , TCHKPSS <- 1)
        if(i_stn == 1){
          CHKPSS <- TCHKPSS
        } else {
          CHKPSS <- c(TCHKPSS,CHKPSS)
        }
      }
      CHKP <- ifelse(sum(CHKPSS) == 0 , "PASS", "WRITE")
      paste(Model_Name,scnnm,"files are already exists")
    } else {
      CHKP <- "WRITE"
      paste(Model_Name,scnnm,"files aren't already exists")
    }


    if(CHKP == "WRITE"){
      print(paste(scnnms[i_scn]," is now running...",sep=""))
      if(scnnm == "historical"){
        syear <- syear_his
        eyear <- eyear_his
      } else {
        syear <- syear_scn
        eyear <- eyear_scn
      }
      QMResults <- list()
      for(i_Var in 1:varcnt){
        vari <- varnms[i_Var]
        ##Read Extracted GCM data
        ##And Save Original GCM and Station Data
        if(vari != "tavg"){
          #Read GCM
          GCMDirF <- paste(indir,"/",Model_Name,"_",scnnm,"_",vari,".csv",sep="")
          ExtractData <- data.frame(fread(GCMDirF)[,"date"],sapply(fread(GCMDirF)[,-1],as.numeric))
          colnames(ExtractData) <- c("date",stnnms)
          #ExtractData <- read.csv(GCMDirF)
          ##Save GCM, Oberservation original data
          for(i_STN in 1:stncnt){
            #Read OBS
            OBSDirF <- paste(prjdir,"/Downscale/OBS/",stnnms[i_STN],"_observed.csv",sep="")
            ExtObsData <- read.csv(OBSDirF)
            stnnm <- stnnms[i_STN]
            if(i_Var == 1){
              GCMTemp[[i_STN]] <- ExtractData[,c("date",stnnm)]
            } else {
              GCMTemp[[i_STN]] <- merge(GCMTemp[[i_STN]],ExtractData[,c("date",stnnm)],by="date")
            }

            if(i_STN == 1){
              OBSTemp[[i_Var]] <- ExtObsData[,c("year","mon","day",vari)]
            } else {
              OBSTemp[[i_Var]] <- merge(OBSTemp[[i_Var]],ExtObsData[,c("year","mon","day",vari)],by=c("year","mon","day"))
            }
          }
          colnames(OBSTemp[[i_Var]]) <- c("year","mon","day",stnnms)
        } else if(vari == "tavg"){
          #Read GCM
          GCMDirF <- paste(indir,"/",Model_Name,"_",scnnm,"_tmax.csv",sep="")
          TempExtract1 <- data.frame(fread(GCMDirF)[,"date"],sapply(fread(GCMDirF)[,-1],as.numeric))
          GCMDirF <- paste(indir,"/",Model_Name,"_",scnnm,"_tmin.csv",sep="")
          TempExtract2 <- data.frame(fread(GCMDirF)[,"date"],sapply(fread(GCMDirF)[,-1],as.numeric))
          date <- TempExtract1[,1]
          ExtractData <- data.frame(date,(TempExtract1[,-1]+TempExtract2[,-1])/2)
          colnames(ExtractData) <- colnames(TempExtract1) <- colnames(TempExtract2) <- c("date",stnnms)
          ##Save GCM original data
          for(i_STN in 1:stncnt){
            #Read OBS
            OBSDirF <- paste(prjdir,"/Downscale/OBS/",stnnms[i_STN],"_observed.csv",sep="")
            ExtObsData <- read.csv(OBSDirF)
            if(i_Var == 1){
              GCMTemp[[i_STN]] <- TempExtract1[,c("date",stnnms[i_STN])]
              GCMTemp[[i_STN]] <- merge(GCMTemp[[i_STN]],TempExtract2[,c("date",stnnms[i_STN])],by="date")
            } else {
              GCMTemp[[i_STN]] <- merge(GCMTemp[[i_STN]],TempExtract1[,c("date",stnnms[i_STN])],by="date")
              GCMTemp[[i_STN]] <- merge(GCMTemp[[i_STN]],TempExtract2[,c("date",stnnms[i_STN])],by="date")
            }
            if(i_STN == 1){
              OBSTemp1[[i_Var]] <- ExtObsData[,c("year","mon","day","tmax")]
              OBSTemp2[[i_Var]] <- ExtObsData[,c("year","mon","day","tmin")]
            } else {
              OBSTemp1[[i_Var]] <- merge(OBSTemp1[[i_Var]],ExtObsData[,c("year","mon","day","tmax")],by=c("year","mon","day"))
              OBSTemp2[[i_Var]] <- merge(OBSTemp2[[i_Var]],ExtObsData[,c("year","mon","day","tmin")],by=c("year","mon","day"))
            }
          }
          colnames(OBSTemp1[[i_Var]]) <- c("year","mon","day",stnnms)
          colnames(OBSTemp2[[i_Var]]) <- c("year","mon","day",stnnms)
        } #if else prcp or temp

        ##Read Station Lists for each grids
        StnLists <- GetSameStationInfo(ExtractData)
        #######Make Quantile Information incase scnnm is historical
        print(paste("Start Read Historical simulation ",Sys.time(),sep=""))
        if(scnnm == "historical"){
          st <- min(which(as.numeric(substr(ExtractData[,1],1,4))==syear))
          et <- max(which(as.numeric(substr(ExtractData[,1],1,4))==eyear))
          GCMOrigin <- ExtractData[st:et,]
          for(i_stn1 in 1:length(StnLists)){
            StnList <- StnLists[[i_stn1]]
            for(i_stn2 in 1:length(StnList)){
              StnInfo <- StnList[i_stn2]
              StnDirF <- paste(obsoutdir,"/",list.files(path=obsoutdir,pattern = StnInfo),sep="")
              Obs <- read.csv(StnDirF)
              if(vari != "tavg"){
                if(i_stn2 == 1){
                  ObsTemp <- Obs[,vari]
                  Tempdate <- paste(Obs[,"year"],"-",
                                    ifelse(Obs[,"mon"]<10,paste("0",Obs[,"mon"],sep=""),Obs[,"mon"]),"-",
                                    ifelse(Obs[,"day"]<10,paste("0",Obs[,"day"],sep=""),Obs[,"day"]),sep="")
                } else{
                  ObsTemp <- data.frame(ObsTemp,Obs[,vari])
                }
              } else if(vari == "tavg"){
                ObsTemp1 <- Obs[,"tmax"]
                ObsTemp2 <- Obs[,"tmin"]
                if(i_stn2 == 1){
                  ObsTemp <- (ObsTemp1+ObsTemp2)/2
                  Tempdate <- paste(Obs[,"year"],"-",
                                    ifelse(Obs[,"mon"]<10,paste("0",Obs[,"mon"],sep=""),Obs[,"mon"]),"-",
                                    ifelse(Obs[,"day"]<10,paste("0",Obs[,"day"],sep=""),Obs[,"day"]),sep="")
                } else{
                  ObsTemp3 <- (ObsTemp1+ObsTemp2)/2
                  ObsTemp <- data.frame(ObsTemp,ObsTemp3)
                }
              }

            } #loop for stns
            if(length(ncol(ObsTemp)>=1)==0){
              AvgObsTemp <- ObsTemp
            } else {
              AvgObsTemp <- apply(ObsTemp,1,mean)
            }
            obsdata <- data.frame(Tempdate,AvgObsTemp)
            rcpdata <- data.frame(GCMOrigin[,"date"],GCMOrigin[,StnLists[[i_stn1]][i_stn2]])
            colnames(obsdata) <- colnames(rcpdata) <- c("date",vari)
            for(j in 1:12){
              qmfnm <- paste("qmf", "_" ,vari, "_", j,"_Grid",i_stn1, sep = "")
              jj <- ifelse(j<10,paste("0",j,sep=""),j)
              wh1 <- which(substr(obsdata[,"date"],6,7)==jj)
              wh2 <- which(substr(rcpdata[,"date"],6,7)==jj)
              obsdatamon <- obsdata[wh1,vari]
              rcpdatamon <- rcpdata[wh2,vari]
              assign(qmfnm, GetQmap(obsdatamon, rcpdatamon))
            } #loop for month
          } #loop for stnlists (Grids)
        } # if scnnm == historical

        print(paste("End Read Historical simulation ",Sys.time(),sep=""))
        cat(paste("Start Monthly Quantile mapping using simulation results on ",vari,sep=""));cat(" \n")
        QMResult <- QMResult1 <- QMResult2 <- list()
        ###Quantile Mapping each Grid
        for(j in 1:12){
          Simuldir <- paste(qmapdir,"/SimulationResults",sep="")
          monthnm <- ifelse(j<10,paste("0",j,sep=""),j)
          SimDirF <- paste(Simuldir,"/",monthnm,"_",vari,".csv",sep="")
          Simdata <- read.csv(SimDirF)

          for(i_stn1 in 1:length(StnLists)){
            StnList <-StnLists[[i_stn1]]
            ##make grid Simulation data
            if(length(StnList)==1){
              TempSim <- Simdata[,StnList]
            } else {
              TempSim <- apply(Simdata[,StnList],1,mean)
            }


            ##Read each grid's Representative values (defined periods)
            stnnm <- StnList[1]
            st <- min(which(substr(ExtractData[,"date"],1,4)==syear))
            et <- max(which(substr(ExtractData[,"date"],1,4)==eyear))
            gcmdataOri <- data.frame(ExtractData[st:et,"date"],ExtractData[st:et,stnnm])
            colnames(gcmdataOri) <- c("date",stnnm)
            whichmon <- which(substr(gcmdataOri[,"date"],6,7)==monthnm)
            gcmdata <- gcmdataOri[whichmon,]
            rcpprd <- gcmdata[,stnnm]
            dates <- gcmdata[,"date"]

            ##Quantile mapping
            qmfnm <- paste("qmf", "_" ,vari, "_", j,"_Grid",i_stn1, sep = "")
            qmf <- get(qmfnm)
            rcpadj <- qmap::doQmap(rcpprd,qmf)
            rcpadj <- data.frame(dates, rcpadj)
            gridnm <- paste("Grid",i_stn1,sep="")
            colnames(rcpadj) <- c("date",gridnm)
            if(i_stn1 == 1){
              Fullgrid <- rcpadj
              Simgrid <- TempSim
            } else {
              Fullgrid <- merge(Fullgrid,rcpadj,by="date")
              Simgrid <- data.frame(Simgrid,TempSim)
            }

          } # loop for Grids
          ###################################
          ##Find which Quantile Mapping results are 0 when variable is prcp
          FullGdata <- Fullgrid[,2:ncol(Fullgrid)]
          ##if grid is 1 then can't calculate apply
          if(ncol(Fullgrid) == 2){
            AvgFull <- FullGdata
          } else {
            AvgFull <- apply(abs(FullGdata),1,mean)
          }
          whAvg <- which(AvgFull==0)
          NumOfFull <- seq(1,nrow(Fullgrid))
          ##delete 0 case
          if(length(whAvg)!=0){
            NumOfFull <- NumOfFull[-whAvg]
          } else {
            NumOfFull <- NumOfFull
          }
          ##############################################
          ##calculate more then 2 grids case // other case
          ##Correlation Matrix
          #cat("Calculate Correlation matrix \n")
          if(length(StnLists) > 1){
            CorrMat <- cor(t(FullGdata),t(Simgrid),method="pearson")
          } else {
            CorrMat <- matrix(99999,length(FullGdata),length(Simgrid))
            for(i_x in 1:length(FullGdata)){
              for(i_y in 1:length(Simgrid)){
                CorrMat[i_x,i_y] <- abs(FullGdata[i_x] - Simgrid[i_y])
              }
            }
          }
          ###Find minimun diff or maximun corr data
          if(vari != "tavg") {
            OutMat <- FindMinErrorMaxCor(vari,Fullgrid,stnnms,NumOfFull,StnLists,CorrMat,Simgrid,FullGdata,Simdata)

            QMResult[[j]] <- data.frame(substr(Fullgrid[,"date"],1,4),as.numeric(substr(Fullgrid[,"date"],6,7)),
                                        as.numeric(substr(Fullgrid[,"date"],9,10)),OutMat)
            colnames(QMResult[[j]]) <- c("year","mon","day",stnnms)
          } else if(vari == "tavg"){
            whOBS1 <- which(OBSTemp1[[i_Var]][,"mon"]==j)
            whOBS2 <- which(OBSTemp2[[i_Var]][,"mon"]==j)
            MonOBStmax <- OBSTemp1[[i_Var]][whOBS1,]
            MonOBStmin <- OBSTemp2[[i_Var]][whOBS2,]
            OutMat <- FindMinErrorMaxCorTavg(vari,Fullgrid,stnnms,NumOfFull,StnLists,CorrMat,Simgrid,FullGdata,Simdata,MonOBStmax,MonOBStmin,MSEmat)
            QMResult1[[j]] <- data.frame(substr(Fullgrid[,"date"],1,4),as.numeric(substr(Fullgrid[,"date"],6,7)),
                                         as.numeric(substr(Fullgrid[,"date"],9,10)),round(OutMat$tmax,3))
            QMResult2[[j]] <- data.frame(substr(Fullgrid[,"date"],1,4),as.numeric(substr(Fullgrid[,"date"],6,7)),
                                         as.numeric(substr(Fullgrid[,"date"],9,10)),round(OutMat$tmin,3))
            colnames(QMResult1[[j]]) <- colnames(QMResult2[[j]]) <- c("year","mon","day",stnnms)
          }

          print(paste(Sys.time(),j,sep=" "))
        } # loop for month
        if(vari != "tavg"){
          QMResults[[i_Var]] <- QMResult
        } else if(vari == "tavg"){
          QMResults[[i_Var]] <- QMResult1
          QMResults[[i_Var+1]] <- QMResult2
        }

      }#loop for varnms


      ##Writie Original GCM data
      scenarios <- length(syear)
      cat(paste("Writing Original GCM or RCM... process now..."));cat("\n")
      for(i_STN in 1:stncnt){
        stnid <- stnnms[i_STN]
        for(i_scn in 1:scenarios){
          if(as.numeric(substr(GCMTemp[[i_STN]][1,"date"],1,4))>syear[i_scn]){
            print("check your Scenarios start periods")
            sd <- GCMTemp[[i_STN]][1,"date"]
          } else {
            sd <- paste(syear[i_scn],"-01-01",sep="")
          }
          if(as.numeric(substr(GCMTemp[[i_STN]][nrow(GCMTemp[[i_STN]]),"date"],1,4))<eyear[i_scn]){
            print("check your Scenarios end periods")
            ed <- GCMTemp[[i_STN]][nrow(GCMTemp[[i_STN]]),"date"]
          } else if(Model_Name == "HadGEM2-CC" | Model_Name == "HadGEM2-ES"){
            ed <- ed <- GCMTemp[[i_STN]][nrow(GCMTemp[[i_STN]]),"date"]
          } else {
            ed <- paste(eyear[i_scn],"-12-31",sep="")
          }
          st <- which(GCMTemp[[i_STN]][,"date"]==sd)
          ed <- which(GCMTemp[[i_STN]][,"date"]==ed)

          out <- GCMTemp[[i_STN]][st:ed,]
          Out <- data.frame(as.numeric(substr(out[,"date"],1,4)),as.numeric(substr(out[,"date"],6,7)),
                            as.numeric(substr(out[,"date"],9,10)),out[,2:ncol(out)])
          colnames(Out) <- c("year","mon","day",Varnms)
          if(i_scn == 1){
            OutDat <- Out
          } else {
            OutDat <- rbind(OutDat,Out)
          }
        } # loop for scenarios
        outfile <- paste(outdir,"/",stnid, "_BCSA_", Model_Name, "_",scnnm,"_original.csv", sep="")
        write.csv(OutDat,outfile,row.names = F)
      } #loop for stnlists
      #X <- QMResults
      ##Write Downscaled Data
      for(i_STN in 1:stncnt){
        stnnm <- stnnms[i_STN]
        for(i_Var in 1:length(QMResults)){
          vari <- Varnms[i_Var]
          TempQMResult <- QMResults[[i_Var]]
          for(j in 1:12){
            TempResult <- TempQMResult[[j]]
            TempResult$year <- as.numeric(as.character(TempResult$year))
            if(j == 1){
              TempQM <- TempResult[,c("year","mon","day",stnnm)]
            } else {
              TempQM <- rbind(TempQM,TempResult[,c("year","mon","day",stnnm)])
            }
          }#loop for month
          colnames(TempQM) <- c("year","mon","day",vari)
          if(i_Var == 1){
            QMapOutResults <- TempQM
          } else {
            QMapOutResults <- merge(QMapOutResults,TempQM,by=c("year","mon","day"))
          }
        }#loop for variables
        rsdate <- as.Date(paste(syear[1],"01-01",sep="-"))
        redate <- as.Date(paste(eyear[length(eyear)],"12-31",sep="-"))
        readdate <- seq(rsdate,redate,by="day")
        if(length(readdate) != nrow(OutDat)){
          ryear <- as.numeric(substr(readdate,1,4))
          rmon <- as.numeric(substr(readdate,6,7))
          rday <- as.numeric(substr(readdate,9,10))
          realmat <- data.frame(ryear,rmon,rday,matrix(-99,length(ryear),length(Varnms)))
          colnames(realmat) <- c("year","mon","day",Varnms)
          REALOUT <- rbind(QMapOutResults,realmat[(nrow(QMapOutResults)+1):nrow(realmat),])
        }
        QMapOutResults <- QMapOutResults[order(QMapOutResults$year,QMapOutResults$mon,QMapOutResults$day),]
        QMResultdir <- paste(qmapdir,"/",Model_Name,sep="")
        if(!dir.exists(QMResultdir)){dir.create(QMResultdir)}
        QMResultdirF <- paste(QMResultdir,"/",stnnm,"_BCSA_",Model_Name,"_",scnnm,".csv",sep="")
        write.csv(QMapOutResults,QMResultdirF,row.names = F)
      }#loop for stnms

    }
  }#loop for rcp scenarios
}

