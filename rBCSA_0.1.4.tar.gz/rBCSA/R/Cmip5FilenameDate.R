#' @export
#'
Cmip5FilenameInfo <- function(fname) {
  
  #fname = "pr_day_bcc-csm1-1_historical_r1i1p1_18500101-20121230.nc"
  #fname = "pr_EAS-0.5_HadGEM2-AO_rcp45_r1i1p1_HadGEM3-RA_v1_day_20060101-20101230.nc"
  
  StrCnt <- length(unlist(strsplit(fname, "_")))

  syear = as.numeric(substr(fname, (nchar(fname)-19),(nchar(fname)-16)))
  smon = as.numeric(substr(fname, (nchar(fname)-15),(nchar(fname)-14)))
  sday = as.numeric(substr(fname, (nchar(fname)-13),(nchar(fname)-12)))
  sdate = as.Date(sprintf("%d-%02d-%02d", syear, smon, sday))
  
  eyear = as.numeric(substr(fname, (nchar(fname)-10),(nchar(fname)-7)))
  emon = as.numeric(substr(fname, (nchar(fname)-6),(nchar(fname)-5)))
  eday = as.numeric(substr(fname, (nchar(fname)-4),(nchar(fname)-3)))
  edate = as.Date(sprintf("%d-%02d-%02d", eyear, emon, eday))
  
  date = seq(sdate, edate, by="day")
  
  varnm = sapply(strsplit(fname, "_"), function(x) x[[1]])
  rcpnm = sapply(strsplit(fname, "_"), function(x) x[[4]])
  
  ### CORDEX ###
  if(StrCnt == 6){
    mdlnm = sapply(strsplit(fname, "_"), function(x) x[[3]])
  } else {
    gcmnm = sapply(strsplit(fname, "_"), function(x) x[[3]])
    mdlnm = sapply(strsplit(fname, "_"), function(x) x[[6]])
  }
  
  outList = list("sdate"=sdate, "edate"=edate, "date"=date, "varnm"=varnm, "mdlnm"=mdlnm, "rcpnm"=rcpnm)
  
  return(outList)
}
