#' @export
#'
Interpolate360Days2Caldendar <- function(df, sdate) {

  library(dplyr)

  sdate <- as.Date(sdate)
  # convert end date of 360 day(1979-12-30) to end date of calendar day (1979-12-31)
  edate <- as.Date(df[length(df[,1]),1])
  # create continuous time series (full dates) as data frame
  day31mon <- c("01","03","05","07","08","10","12")
  if(substr(edate,6,7) == day31mon){
    fdate <- data.frame(seq(sdate, edate+1, by=1))
  } else {
    fdate <- data.frame(seq(sdate, edate, by=1))
  }

  #fdate2 <- data.frame(seq(sdate, edate+1, by=1))
  colnames(fdate) <- "date"
  #colnames(fdate2) <- "date"
  # merge data using all=T
  #test <- merge(fdate, df, by="date", all=T)
  df <- dplyr::left_join(fdate, df, by="date")
  #test2 <- dplyr::left_join(fdate2, df, by="date")
  # interpolate NA between two existing values by excluding date column
  df <- zoo::na.approx(df[2:ncol(df)], na.rm=F)
  #rs2 <- zoo::na.approx(test2[2:ncol(test2)], na.rm=F)
  #df <- zoo::na.approx(df[2:ncol(df)], na.rm=F)
  # fill the last row of missing data using previous values
  df[which(is.na(df[,1])),] <- df[which(is.na(df[,1]))-1,]
  # add date column again
  df <- cbind(fdate,df)

  return(df)
}
