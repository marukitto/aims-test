nscore <- function(x) {
  # Takes a vector of values x and calculates their normal scores. Returns
  # a list with the scores and an ordered table of original values and
  # scores, which is useful as a back-transform table. See backtr().
  nscore <- qqnorm(x, plot.it = FALSE)$x  # normal score
  trn.table <- data.frame(x=sort(x),nscore=sort(nscore))

  return (list(nscore=nscore, trn.table=trn.table))
}

cbindlist <- function(list) {
  n <- length(list)
  res <- NULL
  for (i in seq(n)) res <- cbind(res, list[[i]])
  return(res)
}

rbindlist <-
  function(list) {
    n <- length(list)
    res <- NULL
    for (i in seq(n)) res <- rbind(res, list[[i]])
    return(res)
  }

Read.OBS.data <- function(varnm,stnnms,stndir,syear_obs,eyear_obs){
  OBStemp <- list()
  stncnt <- length(stnnms)
  cat(paste("Variable name is ",varnm,".. process now running...Station..."));cat("\n")
  pb <- txtProgressBar(min=1,max=stncnt,style=3)
  for(i_STN in 1:length(stnnms)){
    setTxtProgressBar(pb,i_STN)
    patnm <- paste(stnnms[i_STN],".csv",sep="")
    fname <- list.files(stndir, pattern = glob2rx(patnm), full.names = F)
    fname <- paste(stndir,"/",fname,sep="")
    temp <- read.csv(fname)
    colnames(temp) <- c("year","mon","day","prcp", "tmax", "tmin", "wspd", "rhum", "rsds", "sshine", "cloud", "tavg")
    temp$ymd <- paste(temp[,"year"],"-",ifelse(temp[,"mon"]<10,paste("0",temp[,"mon"],sep=""),temp[,"mon"]),
                      "-",ifelse(temp[,"day"]<10,paste("0",temp[,"day"],sep=""),temp[,"day"]),sep="")
    sd <- min(which(temp[,"year"]==syear_obs))
    ed <- max(which(temp[,"year"]==eyear_obs))
    tempobs <- temp[sd:ed,]
    OBStemp[[i_STN]] <- as.numeric(tempobs[,varnm])
  }
  close(pb)
  OBS <- cbindlist(OBStemp)
  OBS <- data.frame(tempobs[,"ymd"],OBS)
  colnames(OBS) <- c("ymd",stnnms)
  return(OBS)
}

Find.OBS.month <- function(OBS,monthnm,varnm){
  #find monthname data with out all station prcp 0
  wh <- which(as.numeric(substr(OBS[,"ymd"],6,7))==monthnm)
  TempOBS <- OBS[wh,-1]
  if(varnm == "prcp"){
    Temp <- abs(TempOBS)
  } else {
    Temp <- TempOBS
  }

  Temp$detect <- apply(Temp,1,mean)
  wh <- which(Temp[,"detect"]==0)
  if(length(wh)>0){
    OutOBS <- Temp[-wh,-ncol(Temp)]
  } else {
    OutOBS <- Temp[,-ncol(Temp)]
  }
  return(OutOBS)
}

LU<-function(A){
  n=length(A[,1])
  L<-diag(1,n)
  U<-diag(0,n)

  k=1
  j=1
  i=1
  U[1,]<-A[1,]
  L[,1]<-A[,1]/A[1,1]

  for(k in 2:(n-1)){
    U[k,k] = A[k,k] - sum(L[k,1:(k-1)]*U[1:(k-1),k])
    for(j in (k+1):n){
      U[k,j] = A[k,j] - sum(L[k,1:(k-1)]*U[1:(k-1),j])
    }
    for(i in (k+1):n){
      L[i,k] = ( A[i,k] - sum(L[i,1:(k-1)]*U[1:(k-1),k]) ) / U[k,k]
    }
  }

  U[n,n] = A[n,n] - sum(L[n,1:(n-1)]*U[1:(n-1),n])

  return(list(L=L,U=U))
}

Cholesky<-function(A){
  n=length(A[,1])
  L<-diag(0,n)

  k=1
  L[1,1] = sqrt(A[1,1])
  L[,1] = A[,1]/L[1,1]

  for(k in 2:(n-1)){
    L[k,k] = sqrt(A[k,k] - sum(L[k,1:(k-1)]^2) )
    for(i in (k+1):n){
      L[i,k] = ( A[i,k] - sum( L[i,1:(k-1)] * L[k,1:(k-1)] ) )/L[k,k]
    }
  }

  L[n,n] = sqrt( A[n,n] - sum(L[n,1:(n-1)]^2) )

  return(list(L=L))
}

Back.Transform <- function(Infomat,simulmat,reps){
  #CDFInfo 40980 by 2 Infomat <- CDFInfo
  #rphi  60 by 5000 simulmat <- rphi
  rownum <- nrow(simulmat)
  colnum <- ncol(simulmat)
  Out <- test <- matrix(NA,rownum,colnum)
  cat(paste(".. process now running...Simulation..."));cat("\n")
  pb <- txtProgressBar(min=1,max=reps,style=3)
  for(i in 1:rownum){
    setTxtProgressBar(pb,i)
    for(j in 1:colnum){
      test[i,j] <- min(abs(simulmat[i,j]-Infomat[,2]))
      wh <- which(test[i,j]==abs(simulmat[i,j]-Infomat[,2]))
      Out[i,j] <- Infomat[wh,1]
    }
  }
  close(pb)
  return(Out)
}

BCSA.method.simulation <- function(i_month,OBS,stnnms,reps,varnm){
  Out <- list()
  monthnm <- i_month
  MonOBS <- Find.OBS.month(OBS,monthnm,varnm)
  unliOBS <- unlist(MonOBS);names(unliOBS) <- NULL
  temp <- nscore(unliOBS)
  scaleunliOBS <- temp$nscore
  CDFInfo <- temp$trn.table
  scaleOBS <- matrix(scaleunliOBS,nrow(MonOBS),ncol(MonOBS))
  CorrOBS <- cor(scaleOBS)

  chols <- chol(CorrOBS)
  #Chols <- Cholesky(CorrOBS)$L
  R <- matrix(rnorm((length(stnnms)*reps)),reps,length(stnnms))
  rphi <- R %*% chols

  BT <- Back.Transform(CDFInfo,rphi,reps)
  Out[[1]] <- cor(MonOBS)
  Out[[2]] <- BT
  return(Out)
}

Back.Transform.Stn <- function(Infomat,simulmat,reps){
  #CDFInfo 40980 by 2 Infomat <- CDFInfo
  #rphi  60 by 5000 simulmat <- rphi
  # Infomat <- CDFInfo
  # simulmat <- rphi
  rownum <- nrow(simulmat)
  colnum <- ncol(simulmat)
  Out <- test <- matrix(NA,rownum,colnum)
  cat(paste(".. process now running...Simulation..."));cat("\n")
  pb <- txtProgressBar(min=1,max=reps,style=3)
  for(i in 1:rownum){
    setTxtProgressBar(pb,i)
    for(j in 1:colnum){
      test[i,j] <- min(abs(simulmat[i,j]-Infomat[[j]][,2]))
      wh <- which(test[i,j]==abs(simulmat[i,j]-Infomat[[j]][,2]))
      Out[i,j] <- Infomat[[j]][wh,1]
    }
  }
  close(pb)
  return(Out)
}

BCSA.method.simulation.Stn <- function(i_month,OBS,stnnms,reps,varnm){
  Out <- CDFInfo <- list()
  monthnm <- i_month
  MonOBS <- Find.OBS.month(OBS,monthnm,varnm)
  for(i_stn in 1:ncol(MonOBS)){
    unliOBS <- MonOBS[,i_stn]#;names(unliOBS) <- NULL
    temp <- nscore(unliOBS)
    scaleunliOBS <- temp$nscore
    CDFInfo[[i_stn]] <- temp$trn.table
    if(i_stn == 1){
      scaleOBS <- scaleunliOBS
      R <- rnorm(reps)
    } else {
      scaleOBS <- cbind(scaleOBS,scaleunliOBS)
      R <- cbind(R,rnorm(reps))
    }
  }
  colnames(scaleOBS) <- colnames(R) <- stnnms
  CorrOBS <- cor(scaleOBS)

  chols <- chol(CorrOBS)
  rphi <- R %*% chols

  BT <- Back.Transform.Stn(CDFInfo,rphi,reps)

  Out[[1]] <- MonOBS
  Out[[2]] <- BT
  return(Out)
}

Calculate.Simulation <- function(EnvList,reps,seednum){
  stndir = EnvList$stndir
  stnfile = EnvList$stnfile
  syear_obs = as.numeric(EnvList$syear_obs)
  eyear_obs = as.numeric(EnvList$eyear_obs)
  syear_his = as.numeric(EnvList$syear_his)
  eyear_his = as.numeric(EnvList$eyear_his)
  Cmip5Names = EnvList$Cmip5Names
  vardir = EnvList$qmapdir
  VarNames = EnvList$FixedVarNames
  FixedVarNames <- EnvList$FixedVarNames
  yeardiff <- eyear_obs - syear_obs + 1
  if("prcp"%in%VarNames){VarNames[which(VarNames=="prcp")] <- "prec"}
  VarDFile = paste(stndir, "/", stnfile, sep="")
  if("tmax" %in% FixedVarNames & "tmin" %in% FixedVarNames){
    wh <- which(FixedVarNames=="tmax")
    varnms <- FixedVarNames[-wh]
    wh <- which(varnms == "tmin")
    varnms <- varnms[-wh]
    varnms <- c(varnms,"tavg")
  } else {
    varnms <- FixedVarNames
  }
  ###### Get Station ID, lat, and Lon information
  stnfile = paste(stndir,"/",stnfile,sep="")
  stninfo = read.csv(stnfile, header=T)
  colnames(stninfo) = c("Lon","Lat", "Elev", "ID", "Ename", "SYear")
  stninfo = stninfo[which(stninfo$SYear <= syear_obs),c("ID", "Lon", "Lat", "SYear")]
  stnnms = matrix(stninfo$ID)
  outdir <- paste(vardir,"/SimulationResults",sep="")
  if(!dir.exists(outdir)){dir.create(outdir)}
  set.seed(seednum)

  for(i_Var in 1:length(varnms)){
  #for(i_Var in 1:1){
    varnm <- varnms[i_Var]
    if(varnm == "tavg"){
      tmaxOBS <- Read.OBS.data("tmax",stnnms,stndir,syear_obs,eyear_obs)
      tminOBS <- Read.OBS.data("tmin",stnnms,stndir,syear_obs,eyear_obs)
      ymd <- tminOBS[,1]
      OBS <- data.frame(ymd,(tminOBS[,-1]+tmaxOBS[,-1])/2)
    } else {
      OBS <- Read.OBS.data(varnm,stnnms,stndir,syear_obs,eyear_obs)
    }
    for(i_month in 1:12){
      #for(i_month in 1:1){
      cat(paste("Now ",i_month,"'s month",sep=""))
      if(yeardiff < 10){
        BT <- BCSA.method.simulation(i_month,OBS,stnnms,reps,varnm)
      } else {
        BT <- BCSA.method.simulation.Stn(i_month,OBS,stnnms,reps,varnm)
      }
      out <- BT[[2]]
      colnames(out) <- stnnms
      monthnm <- ifelse(i_month<10,paste("0",i_month,sep=""),i_month)
      outfilenm <- paste(outdir,"/",monthnm,"_",varnm,".csv",sep="")
      write.csv(out,outfilenm,row.names = F)
    }
  }

}




