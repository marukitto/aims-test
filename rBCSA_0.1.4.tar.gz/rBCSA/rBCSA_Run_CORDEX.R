rm(list=ls()) # Be careful! This removes all object in your working environment.

Start <- Sys.time() # Start time of your work

# library(reshape)
# library(doBy)
# library(Matrix)
# library(qmap)
# library(data.table)
# library(PCICt)
##########################################
#### Step 1. Working Environments Setting.
##########################################
EnvList <- SetWorkingEnvironment(envfile = "D:/Repository/rBCSA/rBCSA_CORDEX.yaml")

#######################################
#### Step 2-1. Downscale Daily CMIP5 data
DailyExtractAll(
  ModelDir = EnvList$cmip5dir,
  stndir = EnvList$stndir,
  stnfile = EnvList$stnfile,
  qmapdir = EnvList$qmapdir,
  SimAll = EnvList$SimAll,
  ModelNames = EnvList$Cmip5Names,
  RcpNames = EnvList$RcpNames,
  FixedVarNames = EnvList$FixedVarNames,
  OWrite = EnvList$OWrite
)
#Step 2-1. Downscale Daily CORDEX data
#######################################
DailyExtractAll(
  ModelDir = EnvList$cordexdir,
  stndir = EnvList$stndir,
  stnfile = EnvList$stnfile,
  qmapdir = EnvList$qmapdir,
  SimAll = EnvList$SimAll,
  ModelNames = EnvList$CordexNames,
  RcpNames = EnvList$RcpNames,
  FixedVarNames = EnvList$FixedVarNames,
  OWrite = EnvList$OWrite)

##########################################
#Step3 Simulation#########################
##########################################
reps = 20000
seednum <- 20180807
Calculate.Simulation(EnvList,reps,seednum)
##########################################

stndir = EnvList$stndir
stnfile = EnvList$stnfile
qmapdir = EnvList$qmapdir
prjdir = EnvList$prjdir
SimAll = EnvList$SimAll
RcpNames = EnvList$RcpNames
FixedVarNames = EnvList$FixedVarNames
Cmip5Names = EnvList$Cmip5Names
CordexNames = EnvList$CordexNames
syear_obs = EnvList$syear_obs
eyear_obs = EnvList$eyear_obs
syear_his = EnvList$syear_his
eyear_his = EnvList$eyear_his
syear_scn = EnvList$syear_scn
eyear_scn = EnvList$eyear_scn
OWrite = EnvList$OWrite
SRadiation = EnvList$SRadiation
############################
#### Step 4. Bias-Correction
############################
tic()
DailyQMapAll(stndir, stnfile, qmapdir, prjdir, SimAll, RcpNames, FixedVarNames, syear_obs, Cmip5Names, CordexNames,
                         eyear_obs, syear_his, eyear_his, syear_scn, eyear_scn, OWrite, SRadiation)
toc()
# Bias-Correction Using Quantile Mapping and Save the Bias-Corrected Output for Each Weather Station
# The results are to be stored in project_directory/SQM

End <- Sys.time() # End time of your work.
End - Start # In many cases, it is recommended to check the elapsed time for computing.


#### Some tips.
# 1. A process over this package needs to connect to web server to download required data.
#     This means that unstable internet connectivity fails works.
# 2. If you think it is bothersome to type such a lot of parameters, use the advantage of do.call() built-in function.
#     You can just go with like do.call(DailyQMapAll, EnvList), which makes life easier.

